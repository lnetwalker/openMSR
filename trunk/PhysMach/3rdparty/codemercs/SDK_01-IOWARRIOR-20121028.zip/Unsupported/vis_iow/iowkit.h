//
// IO-Warrior kit library V1.4 include file
//

// IOW Library definitions
#ifndef _IOW_KIT_H_
#define _IOW_KIT_H_

#ifdef _WIN32
#define IOWKIT_API __stdcall
#else
#define IOWKIT_API
#endif // _WIN32

// IO-Warrior vendor & product IDs
#define IOWKIT_VENDOR_ID         0x07c0
#define IOWKIT_VID               IOWKIT_VENDOR_ID
// IO-Warrior 40
#define IOWKIT_PRODUCT_ID_IOW40  0x1500
#define IOWKIT_PID_IOW40         IOWKIT_PRODUCT_ID_IOW40
// IO-Warrior 24
#define IOWKIT_PRODUCT_ID_IOW24  0x1501
#define IOWKIT_PID_IOW24         IOWKIT_PRODUCT_ID_IOW24

// Max number of pipes per IOW device
#define IOWKIT_MAX_PIPES    2

// pipe names
#define IOW_PIPE_IO_PINS      0
#define IOW_PIPE_SPECIAL_MODE 1

// Max number of IOW devices in system
#define IOWKIT_MAX_DEVICES  16
// IOW Legacy devices open modes
#define IOW_OPEN_SIMPLE     1
#define IOW_OPEN_COMPLEX    2

// first IO-Warrior revision with serial numbers
#define IOW_NON_LEGACY_REVISION 0x1010

// Don't forget to pack it!
#pragma pack(push, 1)

typedef struct _IOWKIT_REPORT
 {
  UCHAR ReportID;
  union
   {
    DWORD Value;
    BYTE Bytes[4];
   };
 }
  IOWKIT_REPORT, *PIOWKIT_REPORT;

typedef struct _IOWKIT40_IO_REPORT
 {
  UCHAR ReportID;
  union
   {
    DWORD Value;
    BYTE Bytes[4];
   };
 }
  IOWKIT40_IO_REPORT, *PIOWKIT40_IO_REPORT;

typedef struct _IOWKIT24_IO_REPORT
 {
  UCHAR ReportID;
  union
   {
    WORD Value;
    BYTE Bytes[2];
   };
 }
  IOWKIT24_IO_REPORT, *PIOWKIT24_IO_REPORT;

typedef struct _IOWKIT_SPECIAL_REPORT
 {
  UCHAR ReportID;
  UCHAR Bytes[7];
 }
  IOWKIT_SPECIAL_REPORT, *PIOWKIT_SPECIAL_REPORT;

#define IOWKIT_REPORT_SIZE sizeof(IOWKIT_REPORT)
#define IOWKIT40_IO_REPORT_SIZE sizeof(IOWKIT40_IO_REPORT)
#define IOWKIT24_IO_REPORT_SIZE sizeof(IOWKIT24_IO_REPORT)
#define IOWKIT_SPECIAL_REPORT_SIZE sizeof(IOWKIT_SPECIAL_REPORT)

#pragma pack(pop)

// Opaque IO-Warrior handle
typedef PVOID IOWKIT_HANDLE;

// Function prototypes

#ifdef  __cplusplus
extern "C" {
#endif // __cplusplus

IOWKIT_HANDLE IOWKIT_API IowKitOpenDevice(void);
void IOWKIT_API IowKitCloseDevice(IOWKIT_HANDLE devHandle);
ULONG IOWKIT_API IowKitWrite(IOWKIT_HANDLE devHandle, ULONG numPipe,
  PCHAR buffer, ULONG length);
ULONG IOWKIT_API IowKitRead(IOWKIT_HANDLE devHandle, ULONG numPipe,
  PCHAR buffer, ULONG length);
BOOLEAN IOWKIT_API IowKitReadImmediate(IOWKIT_HANDLE devHandle, PDWORD value);
ULONG IOWKIT_API IowKitGetNumDevs(void);
IOWKIT_HANDLE IOWKIT_API IowKitGetDeviceHandle(ULONG numDevice);
BOOLEAN IOWKIT_API IowKitSetLegacyOpenMode(ULONG legacyOpenMode);
ULONG IOWKIT_API IowKitGetProductId(IOWKIT_HANDLE iowHandle);
ULONG IOWKIT_API IowKitGetRevision(IOWKIT_HANDLE iowHandle);
HANDLE IOWKIT_API IowKitGetThreadHandle(IOWKIT_HANDLE iowHandle);
BOOLEAN IOWKIT_API IowKitGetSerialNumber(IOWKIT_HANDLE iowHandle, PWCHAR serialNumber);
BOOLEAN IOWKIT_API IowKitSetTimeout(IOWKIT_HANDLE devHandle, ULONG timeout);
BOOLEAN IOWKIT_API IowKitSetWriteTimeout(IOWKIT_HANDLE devHandle, ULONG timeout);
BOOLEAN IOWKIT_API IowKitCancelIo(IOWKIT_HANDLE devHandle, ULONG numPipe);
PCHAR IOWKIT_API IowKitVersion(void);

#ifdef  __cplusplus
}
#endif // __cplusplus

#endif // _IOW_KIT_H_
