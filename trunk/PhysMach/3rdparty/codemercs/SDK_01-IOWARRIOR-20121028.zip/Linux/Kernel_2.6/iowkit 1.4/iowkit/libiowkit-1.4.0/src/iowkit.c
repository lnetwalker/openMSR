/*
 * This one's for linux
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
//#include <asm/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
//#include <linux/input.h>
//#include <linux/ioctl.h>
#include <pthread.h>

#include "iowkit.h"
#include "iowarrior.h"

#define TRUE 1
#define FALSE 0

// Name of the device on our filesystem
static const char dev_name[] =  "/dev/usb/iowarrior";
static char KitVersion[] = "IO-Warrior Kit V1.4";

// A mutex to protect the open call
static pthread_mutex_t device_mutex = PTHREAD_MUTEX_INITIALIZER;

typedef
  struct _IowDevice_t
   {
    int dev_num;                  // numeric part of device name for pipe 0
    struct iowarrior_info info;   // All the information available for this device
    int fdIO;                     // the filedescriptor for the io-pins
    int fdSM;                     // the filedescriptor for the special-modes
    struct timeval readTimeout;   // timeout for reading from the device
    struct timeval writeTimeout;  // timeout for writing to the device, not used on linux
    ULONG readTimeoutVal;         // read timeout from IowKitSetTimeout
    ULONG writeTimeoutVal;        // write timeout from IowKitSetWriteTimeout
    ULONG lastValue;
   }
  IowDevice_t;

static IowDevice_t IoWarriors[IOWKIT_MAX_DEVICES];
static ULONG numIoWarriors = 0;

static void IowiClear(void)
 {
  int i;

  for (i = 0; i < numIoWarriors; i++)
   {
    if (IoWarriors[i].fdIO != -1)
      close(IoWarriors[i].fdIO);
    if (IoWarriors[i].fdSM != -1)
      close(IoWarriors[i].fdSM);
   }
  memset(IoWarriors, 0, sizeof(IoWarriors));
  numIoWarriors = 0;
 }

static IowDevice_t *IowiGetDeviceByHandle(IOWKIT_HANDLE iowHandle)
 {
  int i;

  for (i = 0; i < numIoWarriors; i++)
    if ((IowDevice_t *) iowHandle == &IoWarriors[i])
      return &IoWarriors[i];
  return NULL;
 }

IOWKIT_HANDLE IOWKIT_API IowKitOpenDevice(void)
 {
  char ifname[80];              //The filename for the io interface
  struct iowarrior_info info;   //the info for the device
  int i;
  ULONG j;
  int fd;
  int ioctlret;

  pthread_mutex_lock(&device_mutex);
  IowiClear();
  //First step : open the interface 0 of all IOWarriors found
  for(i = 0; i < IOWKIT_MAX_DEVICES*2; i++)
   {
    sprintf(ifname, "%s%d", dev_name, i);
    fd = open(ifname, O_RDWR);
    if(fd != -1)
     {
      //now get the info for this device
      ioctlret = ioctl(fd, IOW_GETINFO, &info);
      if(ioctlret != -1 && info.if_num == 0)
       {
        IoWarriors[numIoWarriors].dev_num = i;
        IoWarriors[numIoWarriors].info = info;
        IoWarriors[numIoWarriors].fdIO = fd;
        IoWarriors[numIoWarriors].fdSM = -1;
        IoWarriors[numIoWarriors].lastValue = 0xFFFFFFFF;
        IoWarriors[numIoWarriors].readTimeoutVal = 0xFFFFFFFF;
        IoWarriors[numIoWarriors].writeTimeoutVal = 0xFFFFFFFF;
        numIoWarriors++;
       }
      else
        close(fd);
     }
   }

  // now look for interface1
  for(i = 0; i < IOWKIT_MAX_DEVICES*2; i++)
   {
    sprintf(ifname, "%s%d", dev_name, i);
    fd = open(ifname, O_RDWR);
    if(fd != -1)
     {
      //now get the info for this device
      ioctlret = ioctl(fd, IOW_GETINFO, &info);
      if(ioctlret != -1 && info.if_num == 1)
       {
        for(j = 0; j < numIoWarriors; j++)
          if (IoWarriors[j].info.product == info.product)
            if(info.serial[0] == '\0' ?
                i - 1 == IoWarriors[j].dev_num : strcmp(IoWarriors[j].info.serial, info.serial) == 0)
             {
              IoWarriors[j].fdSM = fd;
              fd = -1;
              break;
             }
       }
     }
    if (fd != -1)
      close(fd);
   }

  pthread_mutex_unlock(&device_mutex);
  return IowKitGetDeviceHandle(1);
 }


ULONG IOWKIT_API IowKitGetNumDevs(void)
 {
  return numIoWarriors;
 }

IOWKIT_HANDLE IOWKIT_API IowKitGetDeviceHandle(ULONG numDevice)
 {
  if (numDevice >= 1 && numDevice <= numIoWarriors)
    return (IOWKIT_HANDLE) &IoWarriors[numDevice - 1];
  else
    return NULL;
 }

BOOLEAN IOWKIT_API IowKitGetSerialNumber(IOWKIT_HANDLE iowHandle, PWCHAR serialNumber)
 {
  IowDevice_t *dev;

  if (serialNumber == NULL)
    return FALSE;
  dev = IowiGetDeviceByHandle(iowHandle);
  if(dev != NULL)
   {
    int i;

    for(i = 0; i < 9; i++)
      serialNumber[i] = (unsigned short) dev->info.serial[i];
   }
  else
    serialNumber[0] = 0;
  return serialNumber[0] != 0;
 }

ULONG IOWKIT_API IowKitGetProductId(IOWKIT_HANDLE iowHandle)
 {
  IowDevice_t *dev;

  dev = IowiGetDeviceByHandle(iowHandle);
  if(dev != NULL)
    return (ULONG) dev->info.product;
  else
    return 0;
 }

ULONG IOWKIT_API IowKitGetRevision(IOWKIT_HANDLE iowHandle)
 {
  IowDevice_t *dev;

  dev = IowiGetDeviceByHandle(iowHandle);
  if(dev != NULL)
    return (ULONG) dev->info.revision;
  else
    return 0;
 }

void IOWKIT_API IowKitCloseDevice(IOWKIT_HANDLE devHandle)
 { 
  pthread_mutex_lock(&device_mutex);
  IowiClear();
  pthread_mutex_unlock(&device_mutex);
 }


BOOLEAN IOWKIT_API IowKitSetTimeout(IOWKIT_HANDLE devHandle, ULONG timeout)
 {
  IowDevice_t *dev;

  dev = IowiGetDeviceByHandle(devHandle);
  if(dev != NULL)
   {
    dev->readTimeout.tv_sec = (time_t)(timeout / 1000);
    dev->readTimeout.tv_usec = (long) ((timeout % 1000) * 1000);
    dev->readTimeoutVal = timeout;
   }
  return dev != NULL;
 }

BOOLEAN IOWKIT_API IowKitSetWriteTimeout(IOWKIT_HANDLE devHandle, ULONG timeout)
 {
  IowDevice_t *dev;

  dev = IowiGetDeviceByHandle(devHandle);
  if(dev != NULL)
   {
    dev->writeTimeout.tv_sec = (time_t)(timeout / 1000);
    dev->writeTimeout.tv_usec = (long) ((timeout % 1000) * 1000);
    dev->writeTimeoutVal = timeout;
   }
  return dev != NULL;
 }

BOOLEAN IOWKIT_API IowKitSetLegacyOpenMode(ULONG legacyOpenMode)
 {
  return ((legacyOpenMode == IOW_OPEN_SIMPLE) || (legacyOpenMode == IOW_OPEN_COMPLEX));
 }

ULONG IOWKIT_API IowKitRead(IOWKIT_HANDLE devHandle, ULONG numPipe,
  PCHAR buffer, ULONG length)
 {
  IowDevice_t *dev;
  struct timeval tv;
  fd_set rfds;
  int fd;
  ULONG rbc;
  int result, siz, extra;

  dev = IowiGetDeviceByHandle(devHandle);
  if(dev != NULL)
   {
    switch(numPipe)
     {
      case IOW_PIPE_IO_PINS:
        fd = dev->fdIO;
        siz = dev->info.packet_size;
        extra = 1;
        break;
      case IOW_PIPE_SPECIAL_MODE:
        fd = dev->fdSM;
        siz = 8;
        extra = 0;
        break;
      default:
        return 0;
     }
    if (buffer == NULL)
      return 0;
    for(rbc = 0; rbc + siz + extra <= length; )
     {
      tv = dev->readTimeout;
      FD_ZERO(&rfds);      // clear the read-descriptor for select
      FD_SET(fd, &rfds);   // add the filedescriptor to read-descriptor
      if (dev->readTimeoutVal != 0xFFFFFFFF)
        result = select(fd + 1, &rfds, NULL, NULL, &tv);
      else
        result = select(fd + 1, &rfds, NULL, NULL, NULL);
      if(result > 0 && FD_ISSET(fd, &rfds))
       {
        // put in eventual ReportID 0 to be a Windows lookalike
        *buffer = '\0';
        buffer += extra;
        // there should be some data ready for reading now
        if (read(fd, buffer, siz) != siz)
          break;
        buffer += siz;
        rbc += siz + extra;
       }
      else
      // if we encountered a timeout then do not try to read several reports
      if(result == 0)
        break;
     }
    return rbc;
   }
  return 0;
 }

BOOLEAN IOWKIT_API IowKitReadImmediate(IOWKIT_HANDLE devHandle, PDWORD value)
 {
  IowDevice_t *dev;
  struct timeval tv;
  fd_set rfds;
  int result;
  IOWKIT_REPORT report;

  dev = IowiGetDeviceByHandle(devHandle);
  if(dev != NULL)
   {
    if (value == NULL)
      return 0;
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    FD_ZERO(&rfds);            // clear the read-descriptor for select
    FD_SET(dev->fdIO, &rfds);  // add the filedescriptor to read-descriptor
    result = select(dev->fdIO + 1, &rfds, NULL, NULL, &tv);
    if(result > 0 && FD_ISSET(dev->fdIO, &rfds))
     {
      memset(&report, 0, sizeof(report));
      // there should be some data ready for reading now
      if (read(dev->fdIO, &report.Value, dev->info.packet_size) == dev->info.packet_size)
       {
        dev->lastValue = report.Value;
        *value = report.Value; 
        return TRUE;
       }
     }
   }
  *value = dev->lastValue;
  return FALSE;
 }

ULONG IOWKIT_API IowKitWrite(IOWKIT_HANDLE devHandle, ULONG numPipe,
  PCHAR buffer, ULONG length)
 {
  IowDevice_t *dev;
  int fd;
  ULONG rbc;
  int siz, extra;

  dev = IowiGetDeviceByHandle(devHandle);
  if(dev != NULL)
   {
    switch(numPipe)
     {
      case IOW_PIPE_IO_PINS:
        fd = dev->fdIO;
        siz = dev->info.packet_size;
        extra = 1;
        break;
      case IOW_PIPE_SPECIAL_MODE:
        fd = dev->fdSM;
        siz = 8;
        extra = 0;
        break;
      default:
        return 0;
     }
    if (buffer == NULL)
      return 0;
    for(rbc = 0; rbc + siz + extra <= length; rbc += siz + extra)
     {
      buffer += extra;
      if(ioctl(fd, IOW_WRITE, buffer) != 0)
        break;
      buffer += siz;
     }
    return rbc;
   }
  return 0;
 }

BOOLEAN IOWKIT_API IowKitCancelIo(IOWKIT_HANDLE devHandle, ULONG numPipe)
 {
  return FALSE;
 }

HANDLE IOWKIT_API IowKitGetThreadHandle(IOWKIT_HANDLE iowHandle)
 {
  // no threads used for IowKitReadImmediate
  return 0;
 }

PCHAR IOWKIT_API IowKitVersion(void)
 {
  return KitVersion;
 }
