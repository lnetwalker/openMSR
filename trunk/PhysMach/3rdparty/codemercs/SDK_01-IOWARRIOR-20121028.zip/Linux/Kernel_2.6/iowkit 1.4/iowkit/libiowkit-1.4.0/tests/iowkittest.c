//
// ioblink.cpp - Blinking LEDs sample
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "iowkit.h"

#define FALSE 0
#define TRUE 1

// Write simple value
BOOLEAN WriteSimple(IOWKIT_HANDLE devHandle, DWORD value)
{
        IOWKIT_REPORT rep;

        // Init report
        rep.ReportID = 0;
        rep.Value = 0xFFFFFFFF;
        switch (IowKitGetProductId(devHandle))
        {
        // Write simple value to IOW40
        case IOWKIT_PRODUCT_ID_IOW40:
                rep.Bytes[3] = (UCHAR) value;
                return IowKitWrite(devHandle, IOW_PIPE_IO_PINS,
                        (PCHAR) &rep, IOWKIT40_IO_REPORT_SIZE) == IOWKIT40_IO_REPORT_SIZE;
        // Write simple value to IOW24
        case IOWKIT_PRODUCT_ID_IOW24:
                rep.Bytes[0] = (UCHAR) value;
                return IowKitWrite(devHandle, IOW_PIPE_IO_PINS,
                        (PCHAR) &rep, IOWKIT24_IO_REPORT_SIZE) == IOWKIT24_IO_REPORT_SIZE;
        default:
                return FALSE;
        }
}

int main(int argc, char* argv[])
{
        IOWKIT_HANDLE iows[IOWKIT_MAX_DEVICES];
        int i, j;
        ULONG bits;
        int numIows;
        IOWKIT_SPECIAL_REPORT rep;
        unsigned short sn[9];
        char snt[9];
        BOOLEAN rc;
        DWORD pid;
        IOWKIT_HANDLE devHandle;

        // Open device
        devHandle = IowKitOpenDevice();
        if (devHandle == NULL)
        {
                printf("Failed to open device\n");
                goto out;
        }
        // Get number of IOWs in system
        numIows = IowKitGetNumDevs();
        printf("%d IOWs in system\n", numIows);
        // Get all IOW handles
        for (i = 0; i < numIows; i++)
        {
                // Get device handle and init object
                iows[i] = IowKitGetDeviceHandle(i + 1);
                // Get serial number
                IowKitGetSerialNumber(iows[i], sn);
                pid = IowKitGetProductId(iows[i]);
                for (j = 0; j < 9; j++)
                        snt[j] = sn[j];
                printf("%d PID %x, S/N \"%s\"\n", i + 1, (unsigned int) pid, snt);
                IowKitSetWriteTimeout(iows[i], 1000);
        }

        // Init report
        // Report ID 0 is for writing to 32 input/output pins
        rep.ReportID = 0;
        printf("Blinking LEDs...\n");
        //srand(time(NULL));
        // Blinking'
        for (i = 0; i < 100; i++)
        {
                bits = rand();
                //bits = 0x00000000;
                // Make every IOW blink
                for (j = 0; j < numIows; j++)
                {
                        // Write to simple endpoint
                        rc = WriteSimple(iows[j], bits);
                }
                // Sleep for 25ms
                usleep(25000);
        }
        printf("Blinking complete\n");
        // Set LEDs off
        for (i = 0; i < numIows; i++)
                // Write to simple endpoint
                WriteSimple(iows[i], 0xFFFFFFFF);

	IowKitWrite(iows[0], IOW_PIPE_SPECIAL_MODE, (PCHAR) &rep, sizeof(rep));
        for(i = 0; i < 10; i++)
        {
                // Read immediate
                rc = IowKitReadImmediate(iows[0], &bits);
                printf("%d) ReadImm(): rc=%d bits=%x\n", i, rc, (unsigned int) bits);
                usleep(100000);
        }
        // Close device
        IowKitCloseDevice(devHandle);
out:

        return 0;
}
