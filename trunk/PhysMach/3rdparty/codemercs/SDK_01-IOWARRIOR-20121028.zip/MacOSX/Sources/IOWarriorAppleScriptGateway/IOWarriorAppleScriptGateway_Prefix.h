//
// Prefix header for all source files of the 'IOWarriorAppleScriptGateway' target in the 'IOWarriorAppleScriptGateway' project
//

#ifdef __OBJC__
    #import <Cocoa/Cocoa.h>
#endif
