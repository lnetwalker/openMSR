//
//  main.m
//  IOWarrior24Thermometer
//
//  Created by Ilja Iwas on 25.08.06.
//  Copyright __MyCompanyName__ 2006. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
