/*
 *  Util.h
 *  BlinkenWarrior
 *
 *  Created by Ralf Menssen on Wed Feb 04 2004.
 *  Copyright (c) 2004 CodeMercenaries GmbH. All rights reserved.
 *
 */

int BreakActionAvail (void);

