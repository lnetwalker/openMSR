/* BlinkenWarriorAppDelegate */

#import <Cocoa/Cocoa.h>

@interface BlinkenWarriorAppDelegate : NSObject
{
@private
}



@end
