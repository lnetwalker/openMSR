// CaptureTimerDlg.cpp : Implementierungsdatei
//

#include "stdafx.h"
#include "CaptureTimer.h"
#include "CaptureTimerDlg.h"
#include <mmsystem.h>
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CCaptureTimerDlg-Dialogfeld




CCaptureTimerDlg::CCaptureTimerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCaptureTimerDlg::IDD, pParent)
	, mFactor(FALSE)
	, mFactor2(FALSE)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCaptureTimerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_TIMERA_FACTOR, mFactor);
	DDX_Check(pDX, IDC_TIMERA_FACTOR2, mFactor2);
}

BEGIN_MESSAGE_MAP(CCaptureTimerDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_CONNECT_IOW, &CCaptureTimerDlg::OnBnClickedConnectIow)
	ON_BN_CLICKED(IDC_START, &CCaptureTimerDlg::OnBnClickedStart)
	ON_BN_CLICKED(IDC_STOPP, &CCaptureTimerDlg::OnBnClickedStopp)
	ON_BN_CLICKED(IDC_EXIT, &CCaptureTimerDlg::OnBnClickedExit)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_FILE, &CCaptureTimerDlg::OnBnClickedFile)
	ON_BN_CLICKED(IDC_TIMERA_FACTOR, &CCaptureTimerDlg::OnBnClickedTimeraFactor)
	ON_BN_CLICKED(IDC_TIMERA_FACTOR2, &CCaptureTimerDlg::OnBnClickedTimeraFactor2)
	ON_BN_CLICKED(IDC_FILE2, &CCaptureTimerDlg::OnBnClickedFile2)
END_MESSAGE_MAP()


// CCaptureTimerDlg-Meldungshandler

BOOL CCaptureTimerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);

	/*Set all variable to NULL*/
	ioHandle = 0;
	bRun = FALSE;

	for(int i=0; i<6; i++)
	{
		TA_Buf_Fall[i] = 0;
		TA_Buf_Rise[i] = 0;

		TB_Buf_Fall[i] = 0;
		TB_Buf_Rise[i] = 0;
	}

	factor = 0;
	factor2 = 0;
	counter = 0;
	counter2 = 0;
	mFactor = FALSE;
	mFactor2 = FALSE;

	/*Create font for dialog*/
	cFont.CreateFontW(20, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0, DEFAULT_CHARSET, OUT_CHARACTER_PRECIS,CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, _T("sYSTEM"));

	return TRUE;
}

void CCaptureTimerDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // Ger�tekontext zum Zeichnen

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Symbol in Clientrechteck zentrieren
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Symbol zeichnen
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}

	/*Set fon 'cFont' to dialog */
	GetDlgItem(IDC_TIMERA_UP)->SetFont(&cFont);
	GetDlgItem(IDC_TIMERA_DOWN)->SetFont(&cFont);
	GetDlgItem(IDC_TIMERA_DIFF)->SetFont(&cFont);
	GetDlgItem(IDC_TIMERA_UPUP)->SetFont(&cFont);
	GetDlgItem(IDC_TIMERA_DOWNDOWN)->SetFont(&cFont);

	GetDlgItem(IDC_TIMERB_UP)->SetFont(&cFont);
	GetDlgItem(IDC_TIMERB_DOWN)->SetFont(&cFont);
	GetDlgItem(IDC_TIMERB_DIFF)->SetFont(&cFont);
	GetDlgItem(IDC_TIMERB_UPUP)->SetFont(&cFont);
	GetDlgItem(IDC_TIMERB_DOWNDOWN)->SetFont(&cFont);

}


HCURSOR CCaptureTimerDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

/*Create file for log for timer A*/
void CCaptureTimerDlg::OnBnClickedFile()
{
	CString path;
	CFileDialog cDialog(FALSE, 0, 0, 4|2, _T("Config (*.csv) |*.csv||"), 0, 0);

	if(cDialog.DoModal() == IDOK)
	{
		path.Format(_T("%s"), cDialog.GetPathName());
		LogFile.Open(path, CFile::modeCreate | CFile::modeWrite);
	}
}
/*Create file for log for timer B*/
void CCaptureTimerDlg::OnBnClickedFile2()
{
	CString path;
	CFileDialog cDialog(FALSE, 0, 0, 4|2, _T("Config (*.csv) |*.csv||"), 0, 0);

	if(cDialog.DoModal() == IDOK)
	{
		path.Format(_T("%s"), cDialog.GetPathName());
		LogFile2.Open(path, CFile::modeCreate | CFile::modeWrite);
	}
}
/*Function to wirte into log for timer A*/
void CCaptureTimerDlg::WriteLog2(UCHAR id, UCHAR b0, UCHAR b1, UCHAR b2, UCHAR b3, UCHAR b4, UCHAR b5, UCHAR b6, UINT a, UINT b, UINT c)
{
	CString value;
	value.Format(_T("%.2X;%.2X;%.2X;%.2X;%.2X;%.2X;%.2X;%.2X;%d;%d;%d\r\n"), id, b0, b1, b2, b3, b4, b5, b6, a, b, c);
	LogFile.Write((LPCTSTR) value, value.GetLength()*sizeof(TCHAR));
}
/*Function to wirte into log for timer B*/
void CCaptureTimerDlg::WriteLog3(UCHAR id, UCHAR b0, UCHAR b1, UCHAR b2, UCHAR b3, UCHAR b4, UCHAR b5, UCHAR b6, UINT a, UINT b, UINT c)
{
	CString value;
	value.Format(_T("%.2X;%.2X;%.2X;%.2X;%.2X;%.2X;%.2X;%.2X;%d;%d;%d\r\n"), id, b0, b1, b2, b3, b4, b5, b6, a, b, c);
	LogFile2.Write((LPCTSTR) value, value.GetLength()*sizeof(TCHAR));
}

/*Close logfiles*/
void CCaptureTimerDlg::CloseLog(void)
{
	if(LogFile.GetFileName() != _T(""))
		LogFile.Close();

	if(LogFile2.GetFileName() != _T(""))
		LogFile2.Close();
}

/*Format the timestamps into readable values*/
CString CCaptureTimerDlg::MakeMarks(int value)
{
	CString buffer;
	CString dummie[3];
	CString output[3];
	int summ = value;

	for(int i=0; i<3; i++)
	{
		if(i>0)
			summ = summ/1000;
		
		dummie[i].Format(_T("%.3d"), summ);
		output[i].Format(_T("%s"), dummie[i].Right(3));
	}

	buffer.Format(_T("%s'%s'%s"), output[2], output[1], output[0]);

	return buffer;
}

/*Fill the FIFO-Stack with values*/
void CCaptureTimerDlg::ShiftBuffer(int ucase)
{
	switch(ucase)
	{
	case 1: //Timer A falling edge
		TA_Buf_Fall[5] = TA_Buf_Fall[4];
		TA_Buf_Fall[4] = TA_Buf_Fall[3];
		TA_Buf_Fall[3] = TA_Buf_Fall[2];
		TA_Buf_Fall[2] = TA_Buf_Fall[1];
		TA_Buf_Fall[1] = TA_Buf_Fall[0];
		TA_Buf_Fall[0] = 0;
		return;
	case 2: //Timer A riseing edge
		TA_Buf_Rise[5] = TA_Buf_Rise[4];
		TA_Buf_Rise[4] = TA_Buf_Rise[3];
		TA_Buf_Rise[3] = TA_Buf_Rise[2];
		TA_Buf_Rise[2] = TA_Buf_Rise[1];
		TA_Buf_Rise[1] = TA_Buf_Rise[0];
		TA_Buf_Rise[0] = 0;
		return;
	case 4: //Timer B falling edge
		TB_Buf_Fall[5] = TB_Buf_Fall[4];
		TB_Buf_Fall[4] = TB_Buf_Fall[3];
		TB_Buf_Fall[3] = TB_Buf_Fall[2];
		TB_Buf_Fall[2] = TB_Buf_Fall[1];
		TB_Buf_Fall[1] = TB_Buf_Fall[0];
		TB_Buf_Fall[0] = 0;
		return;
	case 8: //Timer B riseing edge
		TB_Buf_Rise[5] = TB_Buf_Rise[4];
		TB_Buf_Rise[4] = TB_Buf_Rise[3];
		TB_Buf_Rise[3] = TB_Buf_Rise[2];
		TB_Buf_Rise[2] = TB_Buf_Rise[1];
		TB_Buf_Rise[1] = TB_Buf_Rise[0];
		TB_Buf_Rise[0] = 0;
		return;
	case 0:
		
		break;
	}
}
/**/
void CALLBACK CCaptureTimerDlg::TimerFunction(UINT wTimerID, UINT msg, DWORD dwUser, DWORD dw1, DWORD dw2)
{
    CCaptureTimerDlg* obj = (CCaptureTimerDlg*)dwUser;
      obj->MMTimerHandler(wTimerID);
}  
/*Multimedia-Timer loop*/
void CCaptureTimerDlg::MMTimerHandler(UINT nIDEvent)
{
	if((ioHandle != NULL) && (bRun == TRUE)) //IO-Warrior must be connect
	{
		IOWKIT_SPECIAL_REPORT rep;
		memset(&rep, 0x00, IOWKIT_SPECIAL_REPORT_SIZE);
		IowKitRead(ioHandle, IOW_PIPE_SPECIAL_MODE, (char*) &rep, IOWKIT_SPECIAL_REPORT_SIZE);

		/*
		Description:

		rep-Structure: ID | Flags | Fall0 | Fall1 | Fall2 | Rise0 | Rise1 | Rise2 
		rep-IDs: 0x29 for timer A, 0x2A for timer B
		Function for falling edge: Fall0 + (256 * Fall1) + (65536 * Fall2)
		Function for riseing edge: Rise0 + (256 * Rise1) + (65536 * Rise2)
		Resolution: 1 step = 4 �S

		Flags for new time A: 
		falling edge: 0x01 (0x05, 0x0D)  (0x 0000 0001)
		riseing edge: 0x02 (0x06, 0x0E)  (0x 0000 0010)
		both edges: 0x03 (0x07, 0x0F)    (0x 0000 0011)

		Flags for new timer B:
		falling edge: 0x04 (0x05, 0x06, 0x07)   (0x 0000 0100)
		riseing edge: 0x08 (0x09, 0x0A, 0x0B)   (0x 0000 1000)
		both edges: 0x0C (0x0D, 0x0E, 0x0F)     (0x 0000 1100)
		*/

		if(rep.ReportID == 0x29) //Check for timer A
		{
			factor++; //increment counter for factor
			if((rep.Bytes[0] == 0x01) || (rep.Bytes[0] == 0x05) || (rep.Bytes[0] == 0x0D)) // detect only falling edges in one rep
			{
				ShiftBuffer(1);
				TA_Buf_Fall[0] = (rep.Bytes[1] + (256 * rep.Bytes[2]) + (65536 * rep.Bytes[3])) & 0x00FFFFFF;

				if(LogFile.GetFileName() != _T(""))
					WriteLog2(rep.ReportID, rep.Bytes[0], rep.Bytes[1], rep.Bytes[2], rep.Bytes[3], rep.Bytes[4], rep.Bytes[5], rep.Bytes[6], 
					rep.Bytes[1] + (256 * rep.Bytes[2]) + (65536 * rep.Bytes[3]), 
					rep.Bytes[4] + (256 * rep.Bytes[5]) + (65536 * rep.Bytes[6]), 
					abs(TA_Buf_Rise[1] - TA_Buf_Fall[2]));

				GetDlgItem(IDC_TIMERA_DOWN)->SetWindowTextW(MakeMarks(TA_Buf_Fall[0]*4));
				
			}

			if((rep.Bytes[0] == 0x02) || (rep.Bytes[0] == 0x06) || (rep.Bytes[0] == 0x0E)) //detect onl riseing edges in one rep
			{
				ShiftBuffer(2);
				TA_Buf_Rise[0] = (rep.Bytes[4] + (256 * rep.Bytes[5]) + (65536 * rep.Bytes[6])) & 0x00FFFFFF;

				if(LogFile.GetFileName() != _T(""))
					WriteLog2(rep.ReportID, rep.Bytes[0], rep.Bytes[1], rep.Bytes[2], rep.Bytes[3], rep.Bytes[4], rep.Bytes[5], rep.Bytes[6], 
					rep.Bytes[1] + (256 * rep.Bytes[2]) + (65536 * rep.Bytes[3]), 
					rep.Bytes[4] + (256 * rep.Bytes[5]) + (65536 * rep.Bytes[6]), 
					abs(TA_Buf_Fall[0] - TA_Buf_Rise[1]));

				GetDlgItem(IDC_TIMERA_UP)->SetWindowTextW(MakeMarks(TA_Buf_Rise[0]*4));
			}

			if((rep.Bytes[0] == 0x03) || (rep.Bytes[0] == 0x07) || (rep.Bytes[0] == 0x0F)) //detect falling and riseing edges in one rep
			{
				ShiftBuffer(1);
				ShiftBuffer(2);

				TA_Buf_Fall[0] = (rep.Bytes[1] + (256 * rep.Bytes[2]) + (65536 * rep.Bytes[3])) & 0x00FFFFFF;
				TA_Buf_Rise[0] = (rep.Bytes[4] + (256 * rep.Bytes[5]) + (65536 * rep.Bytes[6])) & 0x00FFFFFF;

				if(LogFile.GetFileName() != _T(""))
					WriteLog2(rep.ReportID, rep.Bytes[0], rep.Bytes[1], rep.Bytes[2], rep.Bytes[3], rep.Bytes[4], rep.Bytes[5], rep.Bytes[6], 
					rep.Bytes[1] + (256 * rep.Bytes[2]) + (65536 * rep.Bytes[3]), 
					rep.Bytes[4] + (256 * rep.Bytes[5]) + (65536 * rep.Bytes[6]), 
					abs(TA_Buf_Rise[0] - TA_Buf_Fall[0]));
				
				GetDlgItem(IDC_TIMERA_UP)->SetWindowTextW(MakeMarks(TA_Buf_Fall[0]*4));
				GetDlgItem(IDC_TIMERA_DOWN)->SetWindowTextW(MakeMarks(TA_Buf_Rise[0]*4));
			}

			if((rep.Bytes[0] & 0x10) || (rep.Bytes[0] & 0x20) || (rep.Bytes[0] & 0x30)) //detect overruns and ignore them
			{
				if(LogFile.GetFileName() != _T(""))
					WriteLog2(rep.ReportID, rep.Bytes[0], rep.Bytes[1], rep.Bytes[2], rep.Bytes[3], rep.Bytes[4], rep.Bytes[5], rep.Bytes[6], 
					rep.Bytes[1] + (256 * rep.Bytes[2]) + (65536 * rep.Bytes[3]), 
					rep.Bytes[4] + (256 * rep.Bytes[5]) + (65536 * rep.Bytes[6]), 
					0);
			}
		}

		if(rep.ReportID == 0x2A) // Check for timer B
		{
			factor2++; //increment counter two for factor
			if((rep.Bytes[0] == 0x04) || (rep.Bytes[0] == 0x05) || (rep.Bytes[0] == 0x06) || (rep.Bytes[0] == 0x07)) // detect only falling edges in one rep
			{
				ShiftBuffer(4);
				TB_Buf_Fall[0] = (rep.Bytes[1] + (256 * rep.Bytes[2]) + (65536 * rep.Bytes[3])) & 0x00FFFFFF;

				if(LogFile2.GetFileName() != _T(""))
					WriteLog3(rep.ReportID, rep.Bytes[0], rep.Bytes[1], rep.Bytes[2], rep.Bytes[3], rep.Bytes[4], rep.Bytes[5], rep.Bytes[6], 
					rep.Bytes[1] + (256 * rep.Bytes[2]) + (65536 * rep.Bytes[3]), 
					rep.Bytes[4] + (256 * rep.Bytes[5]) + (65536 * rep.Bytes[6]), 
					abs(TB_Buf_Rise[1] - TB_Buf_Fall[2]));

				GetDlgItem(IDC_TIMERB_DOWN)->SetWindowTextW(MakeMarks(TB_Buf_Fall[0]*4));
			}

			if((rep.Bytes[0] == 0x08) || (rep.Bytes[0] == 0x0A) || (rep.Bytes[0] == 0x0B) || (rep.Bytes[0] == 0x09)) // detect only riseing edges in one rep
			{
				ShiftBuffer(8);
				TB_Buf_Rise[0] = (rep.Bytes[4] + (256 * rep.Bytes[5]) + (65536 * rep.Bytes[6])) & 0x00FFFFFF;

				if(LogFile2.GetFileName() != _T(""))
					WriteLog3(rep.ReportID, rep.Bytes[0], rep.Bytes[1], rep.Bytes[2], rep.Bytes[3], rep.Bytes[4], rep.Bytes[5], rep.Bytes[6], 
					rep.Bytes[1] + (256 * rep.Bytes[2]) + (65536 * rep.Bytes[3]), 
					rep.Bytes[4] + (256 * rep.Bytes[5]) + (65536 * rep.Bytes[6]), 
					abs(TB_Buf_Fall[0] - TB_Buf_Rise[1]));

				GetDlgItem(IDC_TIMERB_UP)->SetWindowTextW(MakeMarks(TB_Buf_Rise[0]*4));
			}

			if((rep.Bytes[0] == 0x0C) || (rep.Bytes[0] == 0x0E) || (rep.Bytes[0] == 0x0F) || (rep.Bytes[0] == 0x0D)) // detect falling and riseing edges in one rep
			{
				ShiftBuffer(4);
				ShiftBuffer(8);

				TB_Buf_Fall[0] = (rep.Bytes[1] + (256 * rep.Bytes[2]) + (65536 * rep.Bytes[3])) & 0x00FFFFFF;
				TB_Buf_Rise[0] = (rep.Bytes[4] + (256 * rep.Bytes[5]) + (65536 * rep.Bytes[6])) & 0x00FFFFFF;

				if(LogFile2.GetFileName() != _T(""))
					WriteLog3(rep.ReportID, rep.Bytes[0], rep.Bytes[1], rep.Bytes[2], rep.Bytes[3], rep.Bytes[4], rep.Bytes[5], rep.Bytes[6], 
					rep.Bytes[1] + (256 * rep.Bytes[2]) + (65536 * rep.Bytes[3]), 
					rep.Bytes[4] + (256 * rep.Bytes[5]) + (65536 * rep.Bytes[6]), 
					abs(TB_Buf_Rise[0] - TB_Buf_Fall[0]));
				
				GetDlgItem(IDC_TIMERB_UP)->SetWindowTextW(MakeMarks(TB_Buf_Fall[0]*4));
				GetDlgItem(IDC_TIMERB_DOWN)->SetWindowTextW(MakeMarks(TB_Buf_Rise[0]*4));
			}

			if((rep.Bytes[0] & 0x40) || (rep.Bytes[0] & 0x80) || (rep.Bytes[0] & 0xC0)) // detect overruns
			{
				if(LogFile2.GetFileName() != _T(""))
					WriteLog3(rep.ReportID, rep.Bytes[0], rep.Bytes[1], rep.Bytes[2], rep.Bytes[3], rep.Bytes[4], rep.Bytes[5], rep.Bytes[6], 
					rep.Bytes[1] + (256 * rep.Bytes[2]) + (65536 * rep.Bytes[3]), 
					rep.Bytes[4] + (256 * rep.Bytes[5]) + (65536 * rep.Bytes[6]), 
					0);
			}
		}
		/*Set values to dialog for timer A*/
		if(factor >= counter) 
		{
			/*Show fall-rise*/
			erg1 = abs(TA_Buf_Fall[0] - TA_Buf_Rise[0]) & 0x00FFFFFF;
			GetDlgItem(IDC_TIMERA_DIFF)->SetWindowTextW(MakeMarks(erg1*4));

			/*Show rise-rise*/
			erg2 = abs(TA_Buf_Rise[1] - TA_Buf_Rise[0]) & 0x00FFFFFF;
			GetDlgItem(IDC_TIMERA_UPUP)->SetWindowTextW(MakeMarks(erg2*4));

			/*Show rise-fall*/
			GetDlgItem(IDC_TIMERA_DOWNDOWN)->SetWindowTextW(MakeMarks(erg2*4 - erg1*4));

			factor = 0;
		}

		/*Set values to dialog for timer B*/
		if(factor2 >= counter2)
		{
			/*Show fall-rise*/
			erg4 = abs(TB_Buf_Fall[0] - TB_Buf_Rise[0]) & 0x00FFFFFF;
			GetDlgItem(IDC_TIMERB_DIFF)->SetWindowTextW(MakeMarks(erg4*4));

			/*Show rise-rise*/
			erg5 = abs(TB_Buf_Rise[1] - TB_Buf_Rise[0]) & 0x00FFFFFF;
			GetDlgItem(IDC_TIMERB_UPUP)->SetWindowTextW(MakeMarks(erg5*4));
			
			/*Show rise-fall*/
			GetDlgItem(IDC_TIMERB_DOWNDOWN)->SetWindowTextW(MakeMarks( erg5*4 - erg4*4));

			factor2 = 0;
		}		
	}
}
/*Connect to IO-Warrior24 and check*/
void CCaptureTimerDlg::OnBnClickedConnectIow()
{
ioHandle = IowKitOpenDevice();

	if(ioHandle != NULL)
	{
		ULONG pid = NULL;
		pid = IowKitGetProductId(ioHandle); // Get PID from IO-Warrior

		if(pid == IOWKIT_PID_IOW24) //only IOW24 can use 'Capture Timers'
		{
			IOWKIT_SPECIAL_REPORT report;

			memset(&report, 0x00, IOWKIT_SPECIAL_REPORT_SIZE);
			report.ReportID = 0x28; //Enable capture timers
			report.Bytes[0] = 0x03; //Start capture timer A and timer B; 0x01 = timer A, 0x02 = timer B, 0x03 = timer A and B
			IowKitWrite(ioHandle, IOW_PIPE_SPECIAL_MODE, (char*) &report, IOWKIT_SPECIAL_REPORT_SIZE);
		}
		else
		{
			MessageBox(_T("Found an incompatible IO-Warrior. Please connect an IO-Warrior24 and run again."), _T("Failure"), MB_OK);
			IowKitCloseDevice(ioHandle);
		}
	}
	else
	{
		MessageBox(_T("No IW-Warrior present.\nPlease connect an IO-Warrior and run again."), _T("Failure"), MB_OK);
		IowKitCloseDevice(ioHandle);	
	}
}
/*Start multimedia-timer*/
void CCaptureTimerDlg::OnBnClickedStart()
{
	if(ioHandle != NULL)
	{
		bRun = TRUE;
		/*Multimedia-Timer BEGINN*/
		/*****************************************************/
		TIMECAPS tc;
		timeGetDevCaps(&tc, sizeof(TIMECAPS));
		DWORD resolution = min(max(tc.wPeriodMin, 0), tc.wPeriodMax);
		timeBeginPeriod(resolution);  
		UINT ms = 8; //Set timer to 8 ms

		idEvent = timeSetEvent(ms, resolution, TimerFunction, (DWORD)this, TIME_PERIODIC); 
		/*****************************************************/
	}
}
/*Stop multimedia-timer*/
void CCaptureTimerDlg::OnBnClickedStopp()
{
	bRun = FALSE;
	timeKillEvent(idEvent);
}
/*Exit application*/
void CCaptureTimerDlg::OnBnClickedExit()
{
	CloseLog();

	if(ioHandle != NULL)
	{
		IOWKIT_SPECIAL_REPORT report;

		memset(&report, 0x00, IOWKIT_SPECIAL_REPORT_SIZE);
		report.ReportID = 0x28; //capture timers
		report.Bytes[0] = 0x00; //Disable
		IowKitWrite(ioHandle, IOW_PIPE_SPECIAL_MODE, (char*) &report, IOWKIT_SPECIAL_REPORT_SIZE);
	}

	IowKitCloseDevice(ioHandle);
	OnOK();
}

/*Close dialog with 'X'*/
void CCaptureTimerDlg::OnClose()
{
	CloseLog();
	if(ioHandle != NULL)
	{
		IOWKIT_SPECIAL_REPORT report;

		memset(&report, 0x00, IOWKIT_SPECIAL_REPORT_SIZE);
		report.ReportID = 0x28; //capture timers
		report.Bytes[0] = 0x00; //Disable
		IowKitWrite(ioHandle, IOW_PIPE_SPECIAL_MODE, (char*) &report, IOWKIT_SPECIAL_REPORT_SIZE);
	}
	IowKitCloseDevice(ioHandle);

	CDialog::OnClose();
}



/*Set factor to slow down the dialog for timer A*/
void CCaptureTimerDlg::OnBnClickedTimeraFactor()
{
	UpdateData(TRUE);
	if(mFactor == TRUE)
		counter = 10;
	else
		counter = 0;
	UpdateData(FALSE);
}
/*Set factor to slow down the dialog for timer B*/
void CCaptureTimerDlg::OnBnClickedTimeraFactor2()
{
	UpdateData(TRUE);
	if(mFactor2 == TRUE)
		counter2 = 10;
	else
		counter2 = 0;
	UpdateData(FALSE);
}


