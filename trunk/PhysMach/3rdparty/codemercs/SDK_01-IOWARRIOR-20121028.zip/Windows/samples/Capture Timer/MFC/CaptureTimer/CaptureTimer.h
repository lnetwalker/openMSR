// CaptureTimer.h : Hauptheaderdatei f�r die PROJECT_NAME-Anwendung
//

#pragma once

#ifndef __AFXWIN_H__
	#error "\"stdafx.h\" vor dieser Datei f�r PCH einschlie�en"
#endif

#include "resource.h"		// Hauptsymbole


// CCaptureTimerApp:
// Siehe CaptureTimer.cpp f�r die Implementierung dieser Klasse
//

class CCaptureTimerApp : public CWinApp
{
public:
	CCaptureTimerApp();

// �berschreibungen
	public:
	virtual BOOL InitInstance();

// Implementierung

	DECLARE_MESSAGE_MAP()
};

extern CCaptureTimerApp theApp;