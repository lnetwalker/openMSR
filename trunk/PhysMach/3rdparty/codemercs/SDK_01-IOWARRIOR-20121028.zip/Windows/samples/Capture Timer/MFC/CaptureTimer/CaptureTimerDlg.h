// CaptureTimerDlg.h : Headerdatei
//

#pragma once
#include "iowkit.h"


// CCaptureTimerDlg-Dialogfeld
class CCaptureTimerDlg : public CDialog
{
// Konstruktion
public:
	CCaptureTimerDlg(CWnd* pParent = NULL);	// Standardkonstruktor

// Dialogfelddaten
	enum { IDD = IDD_CAPTURETIMER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterst�tzung


// Implementierung
protected:
	HICON m_hIcon;

	// Generierte Funktionen f�r die Meldungstabellen
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
private:
	static void CALLBACK TimerFunction(UINT wTimerID, UINT msg, DWORD dwUser, DWORD dw1, DWORD dw2);
	void MMTimerHandler(UINT nIDEvent);
public:
	/**/

	IOWKIT_HANDLE ioHandle;
	bool bRun;
	UINT idEvent;
	CFont cFont;
	CFile LogFile;
	CFile LogFile2;

	int TA_Buf_Fall[6];
	int TA_Buf_Rise[6];

	int TB_Buf_Fall[6];
	int TB_Buf_Rise[6];

	/**/

	int factor;
	int factor2;
	int counter;
	int counter2;

	int erg1;
	int erg2;
	int erg3;

	int erg4;
	int erg5;
	int erg6;

	void ShiftBuffer(int ucase);
	CString MakeMarks(int value);
	void WriteLog2(UCHAR id, UCHAR b0, UCHAR b1, UCHAR b2, UCHAR b3, UCHAR b4, UCHAR b5, UCHAR b6, UINT a, UINT b, UINT c);
	void WriteLog3(UCHAR id, UCHAR b0, UCHAR b1, UCHAR b2, UCHAR b3, UCHAR b4, UCHAR b5, UCHAR b6, UINT a, UINT b, UINT c);
	void CloseLog(void);


	
	afx_msg void OnBnClickedConnectIow();
	afx_msg void OnBnClickedStart();
	afx_msg void OnBnClickedStopp();
	afx_msg void OnBnClickedExit();
	afx_msg void OnClose();
	afx_msg void OnBnClickedFile();
	afx_msg void OnBnClickedTimeraFactor();
	BOOL mFactor;
	afx_msg void OnBnClickedTimeraFactor2();
	BOOL mFactor2;
	afx_msg void OnBnClickedFile2();
};
