//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CaptureTimer.rc
//
#define IDD_CAPTURETIMER_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDB_BITMAP2                     130
#define IDB_BITMAP3                     131
#define IDC_CONNECT_IOW                 1000
#define IDC_START                       1001
#define IDC_STOPP                       1002
#define IDC_EXIT                        1003
#define IDC_TIMERA_UP                   1004
#define IDC_TIMERA_DOWN                 1005
#define IDC_TIMERA_DIFF                 1006
#define IDC_TIMERA_DOWNDOWN             1007
#define IDC_TIMERA_UPUP                 1008
#define IDC_FILE                        1009
#define IDC_TIMERA_FACTOR               1010
#define IDC_TIMERB_UP                   1011
#define IDC_TIMERB_DOWN                 1012
#define IDC_TIMERB_DIFF                 1013
#define IDC_TIMERB_DOWNDOWN             1014
#define IDC_TIMERB_UPUP                 1015
#define IDC_TIMERA_FACTOR2              1016
#define IDC_FILE2                       1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
