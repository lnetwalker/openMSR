// KeySimulationDlg.h : Headerdatei
//

#pragma once

#include "iowkit.h"
#include "afxwin.h"


// CKeySimulationDlg-Dialogfeld
class CKeySimulationDlg : public CDialog
{
// Konstruktion
public:
	CKeySimulationDlg(CWnd* pParent = NULL);	// Standardkonstruktor

// Dialogfelddaten
	enum { IDD = IDD_KEYSIMULATION_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterst�tzung


// Implementierung
protected:
	HICON m_hIcon;

	// Generierte Funktionen f�r die Meldungstabellen
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	IOWKIT_HANDLE ioHandle;
	afx_msg void OnClose();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	CButton cBConnect;
	void HidToKeyboard(BYTE Msg, BYTE Event);
	afx_msg void OnBnClickedConnect();
	int iCount;
};
