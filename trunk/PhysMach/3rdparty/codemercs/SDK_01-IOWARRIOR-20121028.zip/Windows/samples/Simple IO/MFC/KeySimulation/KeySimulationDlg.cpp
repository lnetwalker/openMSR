// KeySimulationDlg.cpp : Implementierungsdatei
//

#include "stdafx.h"
#include "KeySimulation.h"
#include "KeySimulationDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CKeySimulationDlg-Dialogfeld

#define START_PUSH 0
#define END_PUSH KEYEVENTF_KEYUP


CKeySimulationDlg::CKeySimulationDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CKeySimulationDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CKeySimulationDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CONNECT, cBConnect);
}

BEGIN_MESSAGE_MAP(CKeySimulationDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_CLOSE()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_CONNECT, &CKeySimulationDlg::OnBnClickedConnect)
END_MESSAGE_MAP()


// CKeySimulationDlg-Meldungshandler

BOOL CKeySimulationDlg::OnInitDialog()
{
	CDialog::OnInitDialog();


	SetIcon(m_hIcon, TRUE);	
	SetIcon(m_hIcon, FALSE);

	SetTimer(IDC_LOOPTIME, 200, NULL);
	ioHandle = NULL;
	iCount = 0;

	return TRUE;
}


void CKeySimulationDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // Ger�tekontext zum Zeichnen

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Symbol in Clientrechteck zentrieren
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Symbol zeichnen
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}


HCURSOR CKeySimulationDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CKeySimulationDlg::OnClose()
{
	IowKitCloseDevice(ioHandle);

	CDialog::OnClose();
}

void CKeySimulationDlg::OnTimer(UINT_PTR nIDEvent)
{
	if(ioHandle != NULL)
	{

		/*Methode with IowKitReadNonBlocking() (for all IOW-Family)*/

		IOWKIT24_IO_REPORT report;
		IowKitReadNonBlocking(ioHandle, IOW_PIPE_IO_PINS, (PCHAR) &report, IOWKIT24_IO_REPORT_SIZE);

		switch(report.Bytes[0])
		{
			case 0xF7:
				if(iCount < 1)
				{
					iCount = 1;
					
					HidToKeyboard(VK_VOLUME_MUTE, START_PUSH);
					HidToKeyboard(VK_VOLUME_MUTE, END_PUSH);
				}
			break;
			case 0xEF:
				if(iCount < 1)
				{
					iCount = 1;
					
					HidToKeyboard(VK_F1, START_PUSH);
					HidToKeyboard(VK_F1, END_PUSH);
				}
			break;
			case 0xDF:
				if(iCount < 1) 
				{
					iCount = 1;
					
					HidToKeyboard(VK_RETURN, START_PUSH);
					HidToKeyboard(VK_RETURN, END_PUSH);
				}
			break;
			case 0xBF:
				if(iCount < 1)
				{
					iCount = 1;
	
					HidToKeyboard(VK_MEDIA_PLAY_PAUSE, START_PUSH);
					HidToKeyboard(VK_MEDIA_PLAY_PAUSE, END_PUSH);
				}
			break;
			case 0x7F:
				if(iCount < 1)
				{
					iCount = 1;
					
					HidToKeyboard(VK_SPACE, START_PUSH);
					HidToKeyboard(VK_SPACE, END_PUSH);
				}
			break;
			case 0xFF:
				iCount = 0;
			break;

			default:
				return;
		}


		/*Methode with IowKitReadImmediate() (only for IOW24 and IOW40)*/

		//DWORD value;
		//IowKitReadImmediate(ioHandle, &value);
		//
		//if(value == 0x0000FFF7)
		//if(iCount < 1)
		//{
		//	iCount = 1;
		//	
		//	HidToKeyboard(VK_VOLUME_MUTE, START_PUSH);
		//	HidToKeyboard(VK_VOLUME_MUTE, END_PUSH);
		//}
		//if(value == 0x0000FFFF)
		//	iCount = 0;

	}

	CDialog::OnTimer(nIDEvent);
}

/*Function to send input-commands to the active application*/
void CKeySimulationDlg::HidToKeyboard(BYTE Msg, BYTE Event)
{
	HWND hwnd = ::GetActiveWindow();

	DWORD idAttach   = GetCurrentThreadId();
	DWORD idAttachTo = GetWindowThreadProcessId(hwnd, NULL);

	AttachThreadInput(idAttach, idAttachTo, TRUE);

	INPUT ipSignal;
	ipSignal.type           = INPUT_KEYBOARD;
	ipSignal.ki.wVk         = Msg;
	ipSignal.ki.wScan       = 0;
	ipSignal.ki.dwFlags     = Event;
	ipSignal.ki.time        = 0;
	ipSignal.ki.dwExtraInfo = 0;
	SendInput(1, &ipSignal, sizeof(ipSignal));

	AttachThreadInput(idAttach, idAttachTo, FALSE);
}
void CKeySimulationDlg::OnBnClickedConnect()
{
	ioHandle = IowKitOpenDevice();
}
