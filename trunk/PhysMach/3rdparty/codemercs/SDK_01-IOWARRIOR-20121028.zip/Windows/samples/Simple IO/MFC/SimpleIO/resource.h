//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Simple IO.rc
//
#define IDD_SIMPLEIO_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDC_REPORT                      1008
#define IDC_SEND                        1009
#define IDC_CHECK1                      1010
#define IDC_CHECK2                      1011
#define IDC_CHECK3                      1012
#define IDC_CHECK4                      1013
#define IDC_CHECK5                      1014
#define IDC_CHECK6                      1015
#define IDC_CHECK7                      1016
#define IDC_CHECK8                      1017
#define IDC_RANDOM                      1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
