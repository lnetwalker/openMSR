<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class Form1
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents TextVal7 As System.Windows.Forms.TextBox
	Public WithEvents TextVal6 As System.Windows.Forms.TextBox
	Public WithEvents TextVal5 As System.Windows.Forms.TextBox
	Public WithEvents TextVal4 As System.Windows.Forms.TextBox
	Public WithEvents ClearAllButton As System.Windows.Forms.Button
	Public WithEvents TextVal3 As System.Windows.Forms.TextBox
	Public WithEvents TextVal2 As System.Windows.Forms.TextBox
	Public WithEvents ReadButton As System.Windows.Forms.Button
	Public WithEvents RandomButton As System.Windows.Forms.Button
	Public WithEvents TextVal1 As System.Windows.Forms.TextBox
	Public WithEvents WriteButton As System.Windows.Forms.Button
	Public WithEvents Image1 As System.Windows.Forms.PictureBox
	Public WithEvents ReadLabel As System.Windows.Forms.Label
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.TextVal7 = New System.Windows.Forms.TextBox
        Me.TextVal6 = New System.Windows.Forms.TextBox
        Me.TextVal5 = New System.Windows.Forms.TextBox
        Me.TextVal4 = New System.Windows.Forms.TextBox
        Me.ClearAllButton = New System.Windows.Forms.Button
        Me.TextVal3 = New System.Windows.Forms.TextBox
        Me.TextVal2 = New System.Windows.Forms.TextBox
        Me.ReadButton = New System.Windows.Forms.Button
        Me.RandomButton = New System.Windows.Forms.Button
        Me.TextVal1 = New System.Windows.Forms.TextBox
        Me.WriteButton = New System.Windows.Forms.Button
        Me.Image1 = New System.Windows.Forms.PictureBox
        Me.ReadLabel = New System.Windows.Forms.Label
        CType(Me.Image1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TextVal7
        '
        Me.TextVal7.AcceptsReturn = True
        Me.TextVal7.BackColor = System.Drawing.SystemColors.Window
        Me.TextVal7.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextVal7.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TextVal7.Location = New System.Drawing.Point(200, 8)
        Me.TextVal7.MaxLength = 0
        Me.TextVal7.Name = "TextVal7"
        Me.TextVal7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextVal7.Size = New System.Drawing.Size(25, 25)
        Me.TextVal7.TabIndex = 11
        Me.TextVal7.Text = "0"
        '
        'TextVal6
        '
        Me.TextVal6.AcceptsReturn = True
        Me.TextVal6.BackColor = System.Drawing.SystemColors.Window
        Me.TextVal6.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextVal6.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TextVal6.Location = New System.Drawing.Point(168, 8)
        Me.TextVal6.MaxLength = 0
        Me.TextVal6.Name = "TextVal6"
        Me.TextVal6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextVal6.Size = New System.Drawing.Size(25, 25)
        Me.TextVal6.TabIndex = 10
        Me.TextVal6.Text = "0"
        '
        'TextVal5
        '
        Me.TextVal5.AcceptsReturn = True
        Me.TextVal5.BackColor = System.Drawing.SystemColors.Window
        Me.TextVal5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextVal5.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TextVal5.Location = New System.Drawing.Point(136, 8)
        Me.TextVal5.MaxLength = 0
        Me.TextVal5.Name = "TextVal5"
        Me.TextVal5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextVal5.Size = New System.Drawing.Size(25, 25)
        Me.TextVal5.TabIndex = 9
        Me.TextVal5.Text = "0"
        '
        'TextVal4
        '
        Me.TextVal4.AcceptsReturn = True
        Me.TextVal4.BackColor = System.Drawing.SystemColors.Window
        Me.TextVal4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextVal4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TextVal4.Location = New System.Drawing.Point(104, 8)
        Me.TextVal4.MaxLength = 0
        Me.TextVal4.Name = "TextVal4"
        Me.TextVal4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextVal4.Size = New System.Drawing.Size(25, 25)
        Me.TextVal4.TabIndex = 8
        Me.TextVal4.Text = "0"
        '
        'ClearAllButton
        '
        Me.ClearAllButton.BackColor = System.Drawing.SystemColors.Control
        Me.ClearAllButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.ClearAllButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ClearAllButton.Location = New System.Drawing.Point(264, 64)
        Me.ClearAllButton.Name = "ClearAllButton"
        Me.ClearAllButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ClearAllButton.Size = New System.Drawing.Size(65, 34)
        Me.ClearAllButton.TabIndex = 7
        Me.ClearAllButton.Text = "Clear All"
        Me.ClearAllButton.UseVisualStyleBackColor = False
        '
        'TextVal3
        '
        Me.TextVal3.AcceptsReturn = True
        Me.TextVal3.BackColor = System.Drawing.SystemColors.Window
        Me.TextVal3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextVal3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TextVal3.Location = New System.Drawing.Point(72, 8)
        Me.TextVal3.MaxLength = 0
        Me.TextVal3.Name = "TextVal3"
        Me.TextVal3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextVal3.Size = New System.Drawing.Size(25, 25)
        Me.TextVal3.TabIndex = 2
        Me.TextVal3.Text = "0"
        '
        'TextVal2
        '
        Me.TextVal2.AcceptsReturn = True
        Me.TextVal2.BackColor = System.Drawing.SystemColors.Window
        Me.TextVal2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextVal2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TextVal2.Location = New System.Drawing.Point(40, 8)
        Me.TextVal2.MaxLength = 0
        Me.TextVal2.Name = "TextVal2"
        Me.TextVal2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextVal2.Size = New System.Drawing.Size(25, 25)
        Me.TextVal2.TabIndex = 1
        Me.TextVal2.Text = "0"
        '
        'ReadButton
        '
        Me.ReadButton.BackColor = System.Drawing.SystemColors.Control
        Me.ReadButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.ReadButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ReadButton.Location = New System.Drawing.Point(8, 64)
        Me.ReadButton.Name = "ReadButton"
        Me.ReadButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ReadButton.Size = New System.Drawing.Size(65, 34)
        Me.ReadButton.TabIndex = 3
        Me.ReadButton.Text = "Read Value"
        Me.ReadButton.UseVisualStyleBackColor = False
        '
        'RandomButton
        '
        Me.RandomButton.BackColor = System.Drawing.SystemColors.Control
        Me.RandomButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.RandomButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RandomButton.Location = New System.Drawing.Point(179, 64)
        Me.RandomButton.Name = "RandomButton"
        Me.RandomButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.RandomButton.Size = New System.Drawing.Size(65, 34)
        Me.RandomButton.TabIndex = 5
        Me.RandomButton.Text = "Random Bits"
        Me.RandomButton.UseVisualStyleBackColor = False
        '
        'TextVal1
        '
        Me.TextVal1.AcceptsReturn = True
        Me.TextVal1.BackColor = System.Drawing.SystemColors.Window
        Me.TextVal1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextVal1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TextVal1.Location = New System.Drawing.Point(8, 8)
        Me.TextVal1.MaxLength = 0
        Me.TextVal1.Name = "TextVal1"
        Me.TextVal1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextVal1.Size = New System.Drawing.Size(25, 25)
        Me.TextVal1.TabIndex = 0
        Me.TextVal1.Text = "0"
        '
        'WriteButton
        '
        Me.WriteButton.BackColor = System.Drawing.SystemColors.Control
        Me.WriteButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.WriteButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.WriteButton.Location = New System.Drawing.Point(94, 64)
        Me.WriteButton.Name = "WriteButton"
        Me.WriteButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.WriteButton.Size = New System.Drawing.Size(65, 34)
        Me.WriteButton.TabIndex = 4
        Me.WriteButton.Text = "Write Value"
        Me.WriteButton.UseVisualStyleBackColor = False
        '
        'Image1
        '
        Me.Image1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Image1.Image = CType(resources.GetObject("Image1.Image"), System.Drawing.Image)
        Me.Image1.Location = New System.Drawing.Point(232, 8)
        Me.Image1.Name = "Image1"
        Me.Image1.Size = New System.Drawing.Size(99, 45)
        Me.Image1.TabIndex = 12
        Me.Image1.TabStop = False
        '
        'ReadLabel
        '
        Me.ReadLabel.BackColor = System.Drawing.SystemColors.Control
        Me.ReadLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.ReadLabel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ReadLabel.Location = New System.Drawing.Point(8, 40)
        Me.ReadLabel.Name = "ReadLabel"
        Me.ReadLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ReadLabel.Size = New System.Drawing.Size(177, 17)
        Me.ReadLabel.TabIndex = 6
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(338, 107)
        Me.Controls.Add(Me.TextVal7)
        Me.Controls.Add(Me.TextVal6)
        Me.Controls.Add(Me.TextVal5)
        Me.Controls.Add(Me.TextVal4)
        Me.Controls.Add(Me.ClearAllButton)
        Me.Controls.Add(Me.TextVal3)
        Me.Controls.Add(Me.TextVal2)
        Me.Controls.Add(Me.ReadButton)
        Me.Controls.Add(Me.RandomButton)
        Me.Controls.Add(Me.TextVal1)
        Me.Controls.Add(Me.WriteButton)
        Me.Controls.Add(Me.Image1)
        Me.Controls.Add(Me.ReadLabel)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Location = New System.Drawing.Point(4, 30)
        Me.Name = "Form1"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "IO-Warrior sample application"
        CType(Me.Image1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
#End Region 
End Class