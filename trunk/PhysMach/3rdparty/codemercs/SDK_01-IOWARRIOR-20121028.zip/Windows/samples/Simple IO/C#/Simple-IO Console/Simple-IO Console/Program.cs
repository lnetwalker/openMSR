﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading;

namespace Simple_IO_Console
{
    class Program
    {
        static uint WriteSimple(IntPtr handle, int value)
        {
            byte[] report = new byte[9];    //Report Bytes for simple i/o function
            uint pid = IOWarrior.Functions.IowKitGetProductId(handle);  //Get PID 
            uint ret = 0;

            report[0] = 0x00;   //Simple-IO mode

            switch (pid)
            {
                case IOWarrior.Defines.IOWKIT_PID_IOW40:

                    report[4] = (byte)value;    //LEDs on starterkit
                    ret = IOWarrior.Functions.IowKitWrite(handle, 0, report, IOWarrior.Defines.IOWKIT40_IO_REPORT_SIZE);
                    
                    break;
                case IOWarrior.Defines.IOWKIT_PID_IOW24:

                    report[1] = (byte)value;    //Port 0 on starterkit
                    ret = IOWarrior.Functions.IowKitWrite(handle, 0, report, IOWarrior.Defines.IOWKIT24_IO_REPORT_SIZE);

                    break;
                case IOWarrior.Defines.IOWKIT_PID_IOW56:

                    report[1] = (byte)value;    //Port 0 on starterkit
                    ret = IOWarrior.Functions.IowKitWrite(handle, 0, report, IOWarrior.Defines.IOWKIT56_IO_REPORT_SIZE);

                    break;
            }

            return ret;
        }

        
        static void Main(string[] args)
        {
            IntPtr handle = IntPtr.Zero;                    //Handle to IO-Warrior device
            uint pid;                                       //ProductID
            StringBuilder sn = new StringBuilder();         //Serialnumber
            uint version;                                   //Firmware version
            byte[] report = new byte[9];                    //Report Bytes for simple i/o function

            handle = IOWarrior.Functions.IowKitOpenDevice();    //Open IO-Warrior device
            pid = IOWarrior.Functions.IowKitGetProductId(handle);
            IOWarrior.Functions.IowKitSetTimeout(handle, 1000);     //Timeout for Read
          
            switch (pid)                                        //Get devicename as string
            {
                case IOWarrior.Defines.IOWKIT_PID_IOW40:
                    Console.WriteLine("Device name: IO-Warrior40");
                    break;
                case IOWarrior.Defines.IOWKIT_PID_IOW24:
                    Console.WriteLine("Device name: IO-Warrior24");
                    break;
                case IOWarrior.Defines.IOWKIT_PID_IOW56:
                    Console.WriteLine("Device name: IO-Warrior56");
                    break;
            }

            IOWarrior.Functions.IowKitGetSerialNumber(handle, sn);      //Get serial number
            Console.WriteLine("Seriennummer: " + sn);
       
            version = IOWarrior.Functions.IowKitGetRevision(handle);    //Get version of firmware
            Console.WriteLine("Firmware version: " + version.ToString("X"));


            Console.WriteLine("\nPress any key to start random writing");
            Console.ReadKey();

            Random rand = new Random();     //Random number
            int a = 0;

            for (int i = 0; i < 15; i++)
            {
                a = rand.Next(1, 255);      //Get random between 1 and 255
                WriteSimple(handle, a);     //Write data to IO-Warrior
                
                Console.WriteLine("Random: " + a.ToString());
                Thread.Sleep(100);
            }

            Console.WriteLine("\nClear IO-Ports...");
            WriteSimple(handle, 255);       //Write 255 (0xFF)

            IOWarrior.Functions.IowKitCloseDevice(handle);              //Close IO-Warrior and release DLL

            Console.WriteLine("\nPress any key to escape...");
            Console.ReadKey();
        }
    }
}
