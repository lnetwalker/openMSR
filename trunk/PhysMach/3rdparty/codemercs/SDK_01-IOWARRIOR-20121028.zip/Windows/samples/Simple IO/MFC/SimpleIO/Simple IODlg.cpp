// Simple IODlg.cpp : implementation file
//

#include "stdafx.h"
#include "Simple IO.h"
#include "Simple IODlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CSimpleIODlg dialog

CSimpleIODlg::CSimpleIODlg(CWnd* pParent /*=NULL*/)
    : CDialog(CSimpleIODlg::IDD, pParent)
{
    m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSimpleIODlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    DDX_Check(pDX, IDC_CHECK8, bit[0]);
    DDX_Check(pDX, IDC_CHECK7, bit[1]);
    DDX_Check(pDX, IDC_CHECK6, bit[2]);
    DDX_Check(pDX, IDC_CHECK5, bit[3]);
    DDX_Check(pDX, IDC_CHECK4, bit[4]);
    DDX_Check(pDX, IDC_CHECK3, bit[5]);
    DDX_Check(pDX, IDC_CHECK2, bit[6]);
    DDX_Check(pDX, IDC_CHECK1, bit[7]);
    DDX_Control(pDX, IDC_REPORT, m_list);
}

BEGIN_MESSAGE_MAP(CSimpleIODlg, CDialog)
    ON_WM_PAINT()
    ON_WM_QUERYDRAGICON()
    //}}AFX_MSG_MAP
    ON_BN_CLICKED(IDC_RANDOM, &CSimpleIODlg::OnBnClickedRandom)
    ON_BN_CLICKED(IDC_CHECK1, &CSimpleIODlg::OnBnClickedCheck1)
    ON_BN_CLICKED(IDC_CHECK2, &CSimpleIODlg::OnBnClickedCheck1)
    ON_BN_CLICKED(IDC_CHECK3, &CSimpleIODlg::OnBnClickedCheck1)
    ON_BN_CLICKED(IDC_CHECK4, &CSimpleIODlg::OnBnClickedCheck1)
    ON_BN_CLICKED(IDC_CHECK5, &CSimpleIODlg::OnBnClickedCheck1)
    ON_BN_CLICKED(IDC_CHECK6, &CSimpleIODlg::OnBnClickedCheck1)
    ON_BN_CLICKED(IDC_CHECK7, &CSimpleIODlg::OnBnClickedCheck1)
    ON_BN_CLICKED(IDC_CHECK8, &CSimpleIODlg::OnBnClickedCheck1)
    ON_WM_CLOSE()
END_MESSAGE_MAP()


// CSimpleIODlg message handlers

BOOL CSimpleIODlg::OnInitDialog()
{
    CDialog::OnInitDialog();

    // Set the icon for this dialog.  The framework does this automatically
    //  when the application's main window is not a dialog
    SetIcon(m_hIcon, TRUE);			// Set big icon
    SetIcon(m_hIcon, FALSE);		// Set small icon

    // TODO: Add extra initialization here

    srand((unsigned int) time(NULL));

    CString list;
    WCHAR sn[9];

    iowHandle = IowKitOpenDevice();
    IowKitGetSerialNumber(iowHandle, sn);


    //Connect to IOWarrior an get the data of it
    if(iowHandle != NULL)
    {
        //Get IOWarrior-family to shown wich byte will be write
        switch(IowKitGetProductId(iowHandle))
        {
            case IOWKIT_PID_IOW24:
            case IOWKIT_PRODUCT_ID_IOWPV1:
            case IOWKIT_PRODUCT_ID_IOWPV2:
                m_list.InsertString(0, "Simple I/O Port: 0");
                break;

            case IOWKIT_PID_IOW40:
                m_list.InsertString(0, "Simple I/O Port: 3");
                break;

            case IOWKIT_PID_IOW56:
                m_list.InsertString(0, "Simple I/O Port: 6");
                break;
        }

        // switch all LEDs off
        WriteSimple(0xff);

        // Print serial number
        list.Format("Serial Number: %S", sn);
        m_list.InsertString(0, list);

        // Print product ID
        list.Format("Product ID: %04x", IowKitGetProductId(iowHandle));
        m_list.InsertString(0, list);
    }
    else
    {
        IowKitCloseDevice(iowHandle);
        MessageBox("Please connect an IOWarrior and run the program again.", "No IOWarrior found", NULL);
        OnOK();
    }

return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSimpleIODlg::OnPaint()
{
    if (IsIconic())
    {
        CPaintDC dc(this); // device context for painting

        SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

        // Center icon in client rectangle
        int cxIcon = GetSystemMetrics(SM_CXICON);
        int cyIcon = GetSystemMetrics(SM_CYICON);
        CRect rect;
        GetClientRect(&rect);
        int x = (rect.Width() - cxIcon + 1) / 2;
        int y = (rect.Height() - cyIcon + 1) / 2;

        // Draw the icon
        dc.DrawIcon(x, y, m_hIcon);
    }
    else
    {
        CDialog::OnPaint();
    }
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSimpleIODlg::OnQueryDragIcon()
{
    return static_cast<HCURSOR>(m_hIcon);
}

void CSimpleIODlg::WriteSimple(BYTE value)
{
    //Write-operation for all IOWarriors
    IOWKIT24_IO_REPORT rep24;
    IOWKIT40_IO_REPORT rep40;
    IOWKIT56_IO_REPORT rep56;

    if(iowHandle != NULL)
    {
        //Get the IOWarrior-family for writing
        switch(IowKitGetProductId(iowHandle))
        {
            case IOWKIT_PID_IOW24:
            case IOWKIT_PRODUCT_ID_IOWPV1:
            case IOWKIT_PRODUCT_ID_IOWPV2:
                memset(&rep24, 0xff, IOWKIT24_IO_REPORT_SIZE);
                rep24.ReportID = 0;
                rep24.Bytes[0] = (BYTE) value;
                IowKitWrite(iowHandle, IOW_PIPE_IO_PINS, (PCHAR) &rep24, IOWKIT24_IO_REPORT_SIZE);
                break;

            case IOWKIT_PID_IOW40:
                memset(&rep40, 0xff, IOWKIT40_IO_REPORT_SIZE);
                rep40.ReportID = 0;
                rep40.Bytes[3] = (BYTE) value;
                IowKitWrite(iowHandle, IOW_PIPE_IO_PINS, (PCHAR) &rep40, IOWKIT40_IO_REPORT_SIZE);
                break;

            case IOWKIT_PID_IOW56:
                memset(&rep56, 0xff, IOWKIT56_IO_REPORT_SIZE);
                rep56.ReportID = 0;
                rep56.Bytes[6] = (BYTE) value;
                IowKitWrite(iowHandle, IOW_PIPE_IO_PINS, (PCHAR) &rep56, IOWKIT56_IO_REPORT_SIZE);
                break;
        }
    }
}

void CSimpleIODlg::OnBnClickedRandom()
{
    BYTE value = 0;

    // Write 100 random values to IOWarrior (blink LEDs)

    for(int i = 0; i < 100; i++)
    {
        value = (rand()*256)/(RAND_MAX+1);

        for(int j = 7; j >= 0; j--)
        {
            bit[j] = value & 1;
            value >>= 1;
        }

        UpdateData(FALSE);
        WriteBits();
        Sleep(50);
    }
}

void CSimpleIODlg::WriteBits(void)
{
    BYTE value = 0;

    UpdateData(TRUE);

    // convert bit values into value for output
    // bits are inverted because IOWarrior pins are low active
    for(int i = 7; i >= 0; i--)
    {
        value <<= 1;
        value |= !bit[i];
    }

    WriteSimple(value);
}

void CSimpleIODlg::OnBnClickedCheck1()
{
	WriteBits();

	UpdateData(FALSE); 
}

void CSimpleIODlg::OnClose()
    {
    // switch off all LEDs
    WriteSimple(0xff);
    // release IOWarrior devices
    IowKitCloseDevice(iowHandle);

    CDialog::OnClose();
    }
