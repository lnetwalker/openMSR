// KeySimulation.h : Hauptheaderdatei f�r die PROJECT_NAME-Anwendung
//

#pragma once

#ifndef __AFXWIN_H__
	#error "\"stdafx.h\" vor dieser Datei f�r PCH einschlie�en"
#endif

#include "resource.h"		// Hauptsymbole


// CKeySimulationApp:
// Siehe KeySimulation.cpp f�r die Implementierung dieser Klasse
//

class CKeySimulationApp : public CWinApp
{
public:
	CKeySimulationApp();

// �berschreibungen
	public:
	virtual BOOL InitInstance();

// Implementierung

	DECLARE_MESSAGE_MAP()
};

extern CKeySimulationApp theApp;