// MAXIM6675.cpp : Legt das Klassenverhalten f�r die Anwendung fest.
//

#include "stdafx.h"
#include "MAXIM6675.h"
#include "MAXIM6675Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMAXIM6675App

BEGIN_MESSAGE_MAP(CMAXIM6675App, CWinApp)
	//{{AFX_MSG_MAP(CMAXIM6675App)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMAXIM6675App Konstruktion

CMAXIM6675App::CMAXIM6675App()
{
}

/////////////////////////////////////////////////////////////////////////////
// Das einzige CMAXIM6675App-Objekt

CMAXIM6675App theApp;

/////////////////////////////////////////////////////////////////////////////
// CMAXIM6675App Initialisierung

BOOL CMAXIM6675App::InitInstance()
{
	// Standardinitialisierung

#ifdef _AFXDLL
	Enable3dControls();			// Diese Funktion bei Verwendung von MFC in gemeinsam genutzten DLLs aufrufen
#else
	Enable3dControlsStatic();	// Diese Funktion bei statischen MFC-Anbindungen aufrufen
#endif

	CMAXIM6675Dlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	// Da das Dialogfeld geschlossen wurde, FALSE zur�ckliefern, so dass wir die
	//  Anwendung verlassen, anstatt das Nachrichtensystem der Anwendung zu starten.
	return FALSE;
}
