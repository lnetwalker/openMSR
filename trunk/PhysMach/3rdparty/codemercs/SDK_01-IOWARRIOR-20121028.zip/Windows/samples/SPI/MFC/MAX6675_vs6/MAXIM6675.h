// MAXIM6675.h : Haupt-Header-Datei f�r die Anwendung MAXIM6675
//

#if !defined(AFX_MAXIM6675_H__D5641791_1723_4E6E_B2CA_2AC1C5FCECE4__INCLUDED_)
#define AFX_MAXIM6675_H__D5641791_1723_4E6E_B2CA_2AC1C5FCECE4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// Hauptsymbole

/////////////////////////////////////////////////////////////////////////////
// CMAXIM6675App:
// Siehe MAXIM6675.cpp f�r die Implementierung dieser Klasse
//

class CMAXIM6675App : public CWinApp
{
public:
	CMAXIM6675App();

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CMAXIM6675App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementierung

	//{{AFX_MSG(CMAXIM6675App)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_MAXIM6675_H__D5641791_1723_4E6E_B2CA_2AC1C5FCECE4__INCLUDED_)
