// MAXIM6675Dlg.cpp : Implementierungsdatei
//

#include "stdafx.h"
#include "MAXIM6675.h"
#include "MAXIM6675Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMAXIM6675Dlg Dialogfeld

CMAXIM6675Dlg::CMAXIM6675Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMAXIM6675Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMAXIM6675Dlg)
		// HINWEIS: Der Klassenassistent f�gt hier Member-Initialisierung ein
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMAXIM6675Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMAXIM6675Dlg)
		// HINWEIS: Der Klassenassistent f�gt an dieser Stelle DDX- und DDV-Aufrufe ein
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMAXIM6675Dlg, CDialog)
	//{{AFX_MSG_MAP(CMAXIM6675Dlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMAXIM6675Dlg Nachrichten-Handler

BOOL CMAXIM6675Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Gro�es Symbol verwenden
	SetIcon(m_hIcon, FALSE);		// Kleines Symbol verwenden
	
	// ZU ERLEDIGEN: Hier zus�tzliche Initialisierung einf�gen
	IOWarrior = IowKitOpenDevice();

    Pid = IowKitGetProductId(IOWarrior);

    if(Pid == IOWKIT_PID_IOW56) 
    {
		IOWKIT56_SPECIAL_REPORT rep56;

        memset(&rep56, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
        rep56.ReportID = 0x08; //SPI-Mode
        rep56.Bytes[0] = 0x01; //Enable SPI-Mode
        rep56.Bytes[1] = 0x01; // mode MSB first, /CPOL, CPHA
        rep56.Bytes[2] = 0xFF; // 93.75 KBit

        IowKitWrite(IOWarrior, IOW_PIPE_SPECIAL_MODE, (char *) &rep56, IOWKIT56_SPECIAL_REPORT_SIZE);

		Timer = SetTimer(1, 1000, NULL);
    }
    else
    if(Pid == IOWKIT_PID_IOW24)
    {
		IOWKIT_SPECIAL_REPORT rep24;

        memset(&rep24, 0, IOWKIT_SPECIAL_REPORT_SIZE);
        rep24.ReportID = 0x08; //SPI-Mode
        rep24.Bytes[0] = 0x01; //Enable SPI-Mode
        rep24.Bytes[1] = 0x07; // mode /CPOL, CPHA, 62.5 KBit

        IowKitWrite(IOWarrior, IOW_PIPE_SPECIAL_MODE, (char *) &rep24, IOWKIT_SPECIAL_REPORT_SIZE);

		Timer = SetTimer(1, 1000, NULL);
    }
	
	return TRUE;  // Geben Sie TRUE zur�ck, au�er ein Steuerelement soll den Fokus erhalten
}

// Wollen Sie Ihrem Dialogfeld eine Schaltfl�che "Minimieren" hinzuf�gen, ben�tigen Sie 
//  den nachstehenden Code, um das Symbol zu zeichnen. F�r MFC-Anwendungen, die das 
//  Dokument/Ansicht-Modell verwenden, wird dies automatisch f�r Sie erledigt.

void CMAXIM6675Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // Ger�tekontext f�r Zeichnen

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Symbol in Client-Rechteck zentrieren
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Symbol zeichnen
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CMAXIM6675Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMAXIM6675Dlg::OnClose() 
{
	if (IOWarrior != NULL)
	{
	    if(Pid == IOWKIT_PID_IOW56) 
		{
			IOWKIT56_SPECIAL_REPORT rep56;

			memset(&rep56, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
			rep56.ReportID = 0x08;
			rep56.Bytes[0] = 0x00;

			IowKitWrite(IOWarrior, IOW_PIPE_SPECIAL_MODE, (char *) &rep56, IOWKIT56_SPECIAL_REPORT_SIZE);
		}
		else
		if(Pid == IOWKIT_PID_IOW24)
		{
			IOWKIT_SPECIAL_REPORT rep24;

			memset(&rep24, 0, IOWKIT_SPECIAL_REPORT_SIZE);
			rep24.ReportID = 0x08;
			rep24.Bytes[0] = 0x00;

			IowKitWrite(IOWarrior, IOW_PIPE_SPECIAL_MODE, (char *) &rep24, IOWKIT_SPECIAL_REPORT_SIZE);
		}

		KillTimer(Timer);
	}

	
	IowKitCloseDevice(IOWarrior);

	CDialog::OnClose();
}

void CMAXIM6675Dlg::OnTimer(UINT nIDEvent) 
{
	if (IOWarrior != NULL)
	{
		double value;
		CString s;

	    if(Pid == IOWKIT_PID_IOW56)
		{
			IOWKIT56_SPECIAL_REPORT rep56;

			memset(&rep56, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
			rep56.ReportID = 0x09; //SPI-Mode
			rep56.Bytes[0] = 0x02; //Write / Read 2 bytes
			rep56.Bytes[1] = 0x00; //flags

			IowKitWrite(IOWarrior, IOW_PIPE_SPECIAL_MODE, (char *) &rep56, IOWKIT56_SPECIAL_REPORT_SIZE);
			IowKitRead(IOWarrior, IOW_PIPE_SPECIAL_MODE, (char *) &rep56, IOWKIT56_SPECIAL_REPORT_SIZE);
			if (rep56.ReportID == 0x09)
			{
				value = (double) (((rep56.Bytes[1] << 8) | rep56.Bytes[2]) >> 3) / 4.0;
				//show temperature
				s.Format("%.2f �C", value);
				CDialog::SetDlgItemText(IDC_STATIC, s);
			}
		}
		else
	    if(Pid == IOWKIT_PID_IOW24)
		{
			IOWKIT_SPECIAL_REPORT rep24;

			memset(&rep24, 0, IOWKIT_SPECIAL_REPORT_SIZE);
			rep24.ReportID = 0x09; //SPI-Mode
			rep24.Bytes[0] = 0x02; //Write / Read 2 Bytes

			IowKitWrite(IOWarrior, IOW_PIPE_SPECIAL_MODE, (char *) &rep24, IOWKIT_SPECIAL_REPORT_SIZE);
			IowKitRead(IOWarrior, IOW_PIPE_SPECIAL_MODE, (char *) &rep24, IOWKIT_SPECIAL_REPORT_SIZE);
			if (rep24.ReportID == 0x09)
			{
				value = (double) (((rep24.Bytes[1] << 8) | rep24.Bytes[2]) >> 3) / 4.0;
				//show temperature
				s.Format("%.2f �C", value);
				CDialog::SetDlgItemText(IDC_STATIC, s);
			}
		}
	}
	
	CDialog::OnTimer(nIDEvent);
}
