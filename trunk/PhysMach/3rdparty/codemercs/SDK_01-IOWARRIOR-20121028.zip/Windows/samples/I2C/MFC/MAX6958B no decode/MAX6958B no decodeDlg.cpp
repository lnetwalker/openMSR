// MAX6958B no decodeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MAX6958B no decode.h"
#include "MAX6958B no decodeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMAX6958BnodecodeDlg dialog

CMAX6958BnodecodeDlg::CMAX6958BnodecodeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMAX6958BnodecodeDlg::IDD, pParent)
	, m_a(FALSE)
	, m_b(FALSE)
	, m_c(FALSE)
	, m_d(FALSE)
	, m_e(FALSE)
	, m_f(FALSE)
	, m_g(FALSE)
	, m_value(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMAX6958BnodecodeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_SEGA, m_a);
	DDX_Check(pDX, IDC_SEGB, m_b);
	DDX_Check(pDX, IDC_SEGC, m_c);
	DDX_Check(pDX, IDC_SEGD, m_d);
	DDX_Check(pDX, IDC_SEGE, m_e);
	DDX_Check(pDX, IDC_SEGF, m_f);
	DDX_Check(pDX, IDC_SEGG, m_g);
}

BEGIN_MESSAGE_MAP(CMAX6958BnodecodeDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_CLEAR, &CMAX6958BnodecodeDlg::OnBnClickedClear)
	ON_BN_CLICKED(IDC_TEST, &CMAX6958BnodecodeDlg::OnBnClickedTest)
	ON_BN_CLICKED(IDC_SEGMENT1, &CMAX6958BnodecodeDlg::OnBnClickedSegment1)
	ON_BN_CLICKED(IDC_SEGMENT2, &CMAX6958BnodecodeDlg::OnBnClickedSegment2)
	ON_BN_CLICKED(IDC_SEGMENT3, &CMAX6958BnodecodeDlg::OnBnClickedSegment3)
	ON_BN_CLICKED(IDC_SEGMENT4, &CMAX6958BnodecodeDlg::OnBnClickedSegment4)
	ON_BN_CLICKED(IDC_CLEARBUTTONS, &CMAX6958BnodecodeDlg::OnBnClickedClearbuttons)
    ON_WM_CLOSE()
END_MESSAGE_MAP()


// CMAX6958BnodecodeDlg message handlers

BOOL CMAX6958BnodecodeDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	iowHandle = IowKitOpenDevice();
    Pid = IowKitGetProductId(iowHandle);
	
	if(iowHandle != NULL)
	{
		IOWKIT56_SPECIAL_REPORT report;

		memset(&report, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
		report.ReportID = 0x01; // Choose IIC-Mode
		report.Bytes[0] = 0x01; // Enable IIC-Mode
        if (Pid == IOWKIT_PID_IOW56)
          report.Bytes[1] = 0x02; // IIC Speed 50kHz
		SendReport(&report);

		memset(&report, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
		report.ReportID = 0x02; // Enable Write-Mode
		report.Bytes[0] = 0xC3; // Start & Stopbit = 1, 3Bytes will be send
		report.Bytes[1] = 0x72; // Address of MAX6958B
		report.Bytes[2] = 0x04; // Normal-Mode for MAX6958B
		report.Bytes[3] = 0x01; // Enable Normal-Mode for MAX6958B
		SendReport(&report);

		memset(&report, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
		report.ReportID = 0x02; // Enable Write-Mode
		report.Bytes[0] = 0xC3; // Start & Stopbit = 1, 3Bytes will be send
		report.Bytes[1] = 0x72; // Address of MAX6958B
		report.Bytes[2] = 0x01; // Decode-Mode for MAX6958B
		report.Bytes[3] = 0x00; // Disable Decode-Mode for MAX6958B
		SendReport(&report);
	}
	else
	{
		MessageBox("Please connect an IOWarrior and run this program again.", "No IOWarrior found", NULL);
		IowKitCloseDevice(iowHandle);
		OnOK();
	}

	m_value = 0;
	
	UpdateData(FALSE);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMAX6958BnodecodeDlg::SendReport(IOWKIT56_SPECIAL_REPORT *report)
{
    switch(Pid)
    {
        case IOWKIT_PID_IOW40:
        case IOWKIT_PID_IOW24:
            IowKitWrite(iowHandle,IOW_PIPE_SPECIAL_MODE, (char *) report, IOWKIT_SPECIAL_REPORT_SIZE);
            break;

        case IOWKIT_PID_IOW56:
            IowKitWrite(iowHandle,IOW_PIPE_SPECIAL_MODE, (char *) report, IOWKIT56_SPECIAL_REPORT_SIZE);
            break;
    }
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMAX6958BnodecodeDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMAX6958BnodecodeDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

HBRUSH CMAX6958BnodecodeDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	HBRUSH hBGBrush = CreateSolidBrush(RGB(255, 0, 0));

	if(pWnd->GetDlgCtrlID() == IDC_SEGA)
	{
		pDC->SetBkColor(RGB(0,255,0));
	}

	return hbr;
//	return hBGBrush;
}


void CMAX6958BnodecodeDlg::SendValue(int display)
{
	IOWKIT56_SPECIAL_REPORT report;

    UpdateData(TRUE);

	m_value = 0;

	memset(&report, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
	report.ReportID = 0x02; //IIC Write-mode
	report.Bytes[0] = 0xC3; //Startbit, Stopbit, 3 Bytes will be send
	report.Bytes[1] = 0x72; //Address of MAX6958B

	//Wich LED(s) are choosen and calculate byte-data
	if(m_a != NULL) m_value = m_value + 64 | m_value;
	if(m_b != NULL) m_value = m_value + 32 | m_value;
	if(m_c != NULL) m_value = m_value + 16 | m_value;
	if(m_d != NULL) m_value = m_value + 8 | m_value;
	if(m_e != NULL) m_value = m_value + 4 | m_value;
	if(m_f != NULL) m_value = m_value + 2 | m_value;
	if(m_g != NULL) m_value = m_value + 1 | m_value;
	
	//Research data and write to choosen display
	for(int i = 0; i < 4 ; i++)
	{
		report.Bytes[2] = display + 31;
		report.Bytes[3] = m_value;
		SendReport(&report);
    }
    UpdateData(FALSE);
}


void CMAX6958BnodecodeDlg::OnBnClickedClear()
{
	IOWKIT56_SPECIAL_REPORT report;
	int dis = 32;

	// Reset the Buttons to "false"
	UpdateData(TRUE);

	m_a = m_b = m_c = m_d = m_e = m_f = m_g = false;

	memset(&report, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
	report.ReportID = 0x02; //IIC Write-mode
	report.Bytes[0] = 0xC3; //Startbit, Stopbit, 3 Bytes will be send
	report.Bytes[1] = 0x72; //Address of MAX6958B
	
	// Research data and write to choosen display
	for(int i = 0; i < 4 ; i++, dis++)
	{
		report.Bytes[2] = dis;
		report.Bytes[3] = 0x00;
		SendReport(&report);
	}

	UpdateData(FALSE);
}

void CMAX6958BnodecodeDlg::OnBnClickedTest()
{
	IOWKIT56_SPECIAL_REPORT report;

	UpdateData(TRUE);

	memset(&report, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
	report.ReportID = 0x02; //IIC Write-mode
	report.Bytes[0] = 0xC3; //Startbit, stopbit, 3 bytes will be sent
	report.Bytes[1] = 0x72; //Address of MAX6958B

	// Loop for all four Displays
	for(int h = 32; h < 36; h++)
	{
		// Loop with all available data to set LEDs
		for(int i = 0; i < 256 ; i++)
		{
			report.Bytes[2] = h;
			report.Bytes[3] = i;
			SendReport(&report);
		}
	}

	UpdateData(FALSE);
}

void CMAX6958BnodecodeDlg::OnBnClickedSegment1()
{
	SendValue(1);
}

void CMAX6958BnodecodeDlg::OnBnClickedSegment2()
{
	SendValue(2);
}

void CMAX6958BnodecodeDlg::OnBnClickedSegment3()
{
	SendValue(3);
}

void CMAX6958BnodecodeDlg::OnBnClickedSegment4()
{
	SendValue(4);
}

void CMAX6958BnodecodeDlg::OnBnClickedClearbuttons()
{
	UpdateData(TRUE);
	m_a = m_b = m_c = m_d = m_e = m_f = m_g = false;
	UpdateData(FALSE);
}

void CMAX6958BnodecodeDlg::OnClose()
{
    if(iowHandle != NULL)
    {
        IOWKIT56_SPECIAL_REPORT report;

        OnBnClickedClear();
        memset(&report, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
        report.ReportID = 0x01; // Choose IIC-Mode
        report.Bytes[0] = 0x00; // Disable IIC-Mode
        SendReport(&report);
    }
    IowKitCloseDevice(iowHandle);

    CDialog::OnClose();
}
