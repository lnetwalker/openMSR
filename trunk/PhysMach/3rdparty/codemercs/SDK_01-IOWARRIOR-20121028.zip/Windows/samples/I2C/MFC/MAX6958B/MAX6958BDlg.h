// MAX6958BDlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "iowkit.h"
#include "afxcmn.h"


// CMAX6958BDlg dialog
class CMAX6958BDlg : public CDialog
{
// Construction
public:
	CMAX6958BDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_MAX6958B_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CString m_value;
	BOOL m_test;
	CListBox m_reportlist;
	CString m_lastsend;
	int m_slider;
	CSliderCtrl m_sliderctrl;
	BOOL m_onoff;
	afx_msg void OnBnClickedOnoff();
	int m_light;
	afx_msg void OnBnClickedTest();
	afx_msg void OnBnClickedReset();
	afx_msg void OnBnClickedSend();
	afx_msg void OnBnClickedClear();
	afx_msg void OnNMCustomdrawBrightness2(NMHDR *pNMHDR, LRESULT *pResult);
    afx_msg void OnClose();
public:
	IOWKIT_HANDLE iowHandle;
    ULONG Pid;
    void SendReport(IOWKIT56_SPECIAL_REPORT *report);
};
