// stdafx.cpp : Quelldatei, die nur die Standard-Includes einbindet
// HumTemp.pch ist der vorkompilierte Header
// stdafx.obj enth�lt die vorkompilierten Typinformationen

#include "stdafx.h"


