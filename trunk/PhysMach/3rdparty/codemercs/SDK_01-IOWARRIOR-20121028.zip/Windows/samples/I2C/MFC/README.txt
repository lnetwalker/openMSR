Most of the I2C examples are for a MAX127 A/D chip. Only the MFC examples are for a MAX6958B 7-Segment chip.
The MAX127 examples do not support the IOWarrior 56 only due to lack of a test device.

"Sensibus" use a special varriant of I2C Mode and is only with IO-Warrior24 compatible.
It will use the SH17xx humidity sensor from Sensirion.