//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MAXIM127.rc
//
#define IDD_MAXIM127_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define Value1                          1001
#define Value2                          1002
#define Value3                          1003
#define Value4                          1004
#define Value5                          1005
#define Value6                          1006
#define Value7                          1007
#define Value8                          1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
