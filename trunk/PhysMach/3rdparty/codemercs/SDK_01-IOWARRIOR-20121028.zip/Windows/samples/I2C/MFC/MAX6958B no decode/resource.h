//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MAX6958B no decode.rc
//
#define IDD_MAX6958BNODECODE_DIALOG     102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP2                     130
#define IDC_SEGA                        1001
#define IDC_SEND                        1002
#define IDC_DISPLAY1                    1003
#define IDC_TEST                        1004
#define IDC_CLEAR                       1005
#define IDC_SEGMENT1                    1006
#define IDC_SEGMENT2                    1007
#define IDC_SEGMENT3                    1008
#define IDC_SEGMENT4                    1009
#define IDC_TEST2                       1010
#define IDC_CLEARBUTTONS                1010
#define IDC_SEGB                        1015
#define IDC_SEGC                        1016
#define IDC_SEGD                        1017
#define IDC_SEGE                        1018
#define IDC_SEGF                        1019
#define IDC_SEGG                        1020
#define IDC_SEGDP                       1021
#define IDC_DISPLAY2                    1022
#define IDC_DISPLAY3                    1023
#define IDC_DISPLAY4                    1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
