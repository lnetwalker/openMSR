// MAXIM127Dlg.cpp : Implementierungsdatei
//

#include "stdafx.h"
#include "MAXIM127.h"
#include "MAXIM127Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMAXIM127Dlg Dialogfeld

CMAXIM127Dlg::CMAXIM127Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMAXIM127Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMAXIM127Dlg)
		// HINWEIS: Der Klassenassistent f�gt hier Member-Initialisierung ein
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMAXIM127Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMAXIM127Dlg)
		// HINWEIS: Der Klassenassistent f�gt an dieser Stelle DDX- und DDV-Aufrufe ein
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMAXIM127Dlg, CDialog)
	//{{AFX_MSG_MAP(CMAXIM127Dlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMAXIM127Dlg Nachrichten-Handler

BOOL CMAXIM127Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Gro�es Symbol verwenden
	SetIcon(m_hIcon, FALSE);		// Kleines Symbol verwenden
	
	// ZU ERLEDIGEN: Hier zus�tzliche Initialisierung einf�gen
	IOWarrior = IowKitOpenDevice();
	if (IOWarrior != NULL)
	{
		IOWKIT_SPECIAL_REPORT report;

		Pid = IowKitGetProductId(IOWarrior);
		switch (Pid)
		{
			case IOWKIT_PID_IOW40:
			case IOWKIT_PID_IOW24:
				memset(&report, 0, IOWKIT_SPECIAL_REPORT_SIZE);
				report.ReportID = 0x1;
				report.Bytes[0] = 0x1; // enable IIC
				IowKitWrite(IOWarrior, IOW_PIPE_SPECIAL_MODE, (char *) &report, IOWKIT_SPECIAL_REPORT_SIZE);
				break;
		}
		Timer = SetTimer(1, 200, NULL);
	}
	
	return TRUE;  // Geben Sie TRUE zur�ck, au�er ein Steuerelement soll den Fokus erhalten
}

// Wollen Sie Ihrem Dialogfeld eine Schaltfl�che "Minimieren" hinzuf�gen, ben�tigen Sie 
//  den nachstehenden Code, um das Symbol zu zeichnen. F�r MFC-Anwendungen, die das 
//  Dokument/Ansicht-Modell verwenden, wird dies automatisch f�r Sie erledigt.

void CMAXIM127Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // Ger�tekontext f�r Zeichnen

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Symbol in Client-Rechteck zentrieren
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Symbol zeichnen
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CMAXIM127Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMAXIM127Dlg::OnClose() 
{
	if (IOWarrior != NULL)
	{
		IOWKIT_SPECIAL_REPORT report;

		KillTimer(Timer);
		switch (Pid)
		{
			case IOWKIT_PID_IOW40:
			case IOWKIT_PID_IOW24:
				memset(&report, 0, IOWKIT_SPECIAL_REPORT_SIZE);
				report.ReportID = 0x1;
				report.Bytes[0] = 0x0; // disable IIC
				IowKitWrite(IOWarrior, IOW_PIPE_SPECIAL_MODE, (char *) &report, IOWKIT_SPECIAL_REPORT_SIZE);
				break;
		}
	}

	IowKitCloseDevice(IOWarrior);
	
	CDialog::OnClose();
}

void CMAXIM127Dlg::OnTimer(UINT nIDEvent) 
{
	if (IOWarrior != NULL)
	{
		IOWKIT_SPECIAL_REPORT report;
		int n;
		CString s;

		if (Pid == IOWKIT_PID_IOW24 || Pid == IOWKIT_PID_IOW40)
			for(int i = 0; i < 8; i++)
			{
				memset(&report, 0, sizeof(report));
				report.ReportID = 0x02; // ReportID IIC write request
				report.Bytes[0] = 0xC2; // 2 bytes with IIC Start and Stop
				report.Bytes[1] = 0x50; // MAXIM127 address byte = ADR 0, write
				// MAXIM127 control byte
				// START, I = Channel index, +/-10 V = RNG 1 and BIP 1, normal operation
				report.Bytes[2] = 0x8C | (i << 4);
				IowKitWrite(IOWarrior, IOW_PIPE_SPECIAL_MODE, (char *) &report, sizeof(report));
				// swallow ACK report
				IowKitRead(IOWarrior, IOW_PIPE_SPECIAL_MODE, (char *) &report, sizeof(report));

				memset(&report, 0, sizeof(report));
				report.ReportID = 0x03; // ReportID IIC write request
				report.Bytes[0] = 0x02; // 2 bytes with IIC Start and Stop
				report.Bytes[1] = 0x51; // MAXIM127 address byte = ADR 0, read
				// MAXIM127 control byte
				// START, I = Channel index, +/-10 V = RNG 1 and BIP 1, normal operation
				report.Bytes[2] = 0x8C | (i << 4);
				IowKitWrite(IOWarrior, IOW_PIPE_SPECIAL_MODE, (char *) &report, IOWKIT_SPECIAL_REPORT_SIZE);
				// read answer containing voltage value
				IowKitRead(IOWarrior, IOW_PIPE_SPECIAL_MODE, (char *) &report, IOWKIT_SPECIAL_REPORT_SIZE);

				// extract bytes of value
				n = (report.Bytes[1] << 8) | report.Bytes[2];
				// value is upper 12 bits of 16 bits
				n >>= 4;
				// value is 12 bit signed!
				// We need to add the upper twos complement sign bits for the Integer.
				// This is a sign extension from 12 bit to 32 bit.
				if (n & 0x800)
					n |= 0xFFFFF000;
				// value now is a signed integer with 2047 = 10 V and -2047 = -10 V
				s.Format("%.2f", (float) n * 10.0 / 2048.0);
				CDialog::SetDlgItemText(Value1 + i, s);
			}
	}
	
	CDialog::OnTimer(nIDEvent);
}
