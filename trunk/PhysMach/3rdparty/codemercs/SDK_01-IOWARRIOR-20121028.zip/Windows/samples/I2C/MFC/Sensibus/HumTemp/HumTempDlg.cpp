// HumTempDlg.cpp : Implementierungsdatei
//

#include "stdafx.h"
#include "HumTemp.h"
#include "HumTempDlg.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


#define HUMIDITY 0x05
#define TEMPERATURE 0x03

// CHumTempDlg-Dialogfeld




CHumTempDlg::CHumTempDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHumTempDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDI_ICON1);
}

void CHumTempDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CHumTempDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_CLOSE()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_START, &CHumTempDlg::OnBnClickedStart)
END_MESSAGE_MAP()


// CHumTempDlg-Meldungshandler

BOOL CHumTempDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Gro�es Symbol verwenden
	SetIcon(m_hIcon, FALSE);		// Kleines Symbol verwenden

	temperature = 0.00;
	humidity = 0.00;

	cFont.CreateFontW(32, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, OUT_CHARACTER_PRECIS,CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, _T("Arial"));

	GetDlgItem(IDC_STATIC_HUMIDITY)->SetFont(&cFont);
	GetDlgItem(IDC_STATIC_TEMPERATURE)->SetFont(&cFont);
	GetDlgItem(IDC_STATIC_DEWPOINT)->SetFont(&cFont);


	return TRUE;
}

void CHumTempDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // Ger�tekontext zum Zeichnen

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Symbol in Clientrechteck zentrieren
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Symbol zeichnen
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CHumTempDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CHumTempDlg::OnClose()
{
	if(ioHandle != NULL){

		IOWKIT_SPECIAL_REPORT report;
		memset(&report, 0x00, IOWKIT_SPECIAL_REPORT_SIZE);

		report.ReportID = 0x01; //I2C-Mode
		report.Bytes[0] = 0x00; //Disable

		IowKitWrite(ioHandle, IOW_PIPE_SPECIAL_MODE, (char*) &report, IOWKIT_SPECIAL_REPORT_SIZE);
		
		IowKitCloseDevice(ioHandle);	//close all IO-Warrior
		ioHandle = NULL;

		KillTimer(IDC_LOOPTIME);		//kill timer
	}

	CDialog::OnClose();
}

void CHumTempDlg::OnTimer(UINT_PTR nIDEvent)
{
	CString string;

	if(ioHandle != NULL){
		humidity = ReadI2C(HUMIDITY);						//Read the humidity over I2C
		temperature = ReadI2C(TEMPERATURE);					//Read the temperature over I2C

		CalcTRH(&humidity, &temperature);					//calc humidity and temperature
		dewpoint = calc_dewpoint(humidity, temperature);	//calc dew point


		// Set the dialog-elements
		string.Format(_T("%.2f %sRH"), humidity, _T("%"));
		GetDlgItem(IDC_STATIC_HUMIDITY)->SetWindowTextW(string);

		string.Format(_T("%.2f �C"), temperature);
		GetDlgItem(IDC_STATIC_TEMPERATURE)->SetWindowTextW(string);

		string.Format(_T("%.2f �C"), dewpoint);
		GetDlgItem(IDC_STATIC_DEWPOINT)->SetWindowTextW(string);

	}
	CDialog::OnTimer(nIDEvent);
}

short CHumTempDlg::ReadI2C(UCHAR call)
{
	IOWKIT_SPECIAL_REPORT report;
	memset(&report, 0x00, IOWKIT_SPECIAL_REPORT_SIZE);
	short result = 0;

	report.ReportID = 0x03;			//I2C-Read
	report.Bytes[0] = 0x03;			//Read 3 Bytes
	report.Bytes[1] = call;			//Address for humidity or temperature

	IowKitWrite(ioHandle, IOW_PIPE_SPECIAL_MODE, (char*) &report, IOWKIT_SPECIAL_REPORT_SIZE);
	IowKitRead(ioHandle, IOW_PIPE_SPECIAL_MODE, (char*) &report, IOWKIT_SPECIAL_REPORT_SIZE);

	result = (report.Bytes[1] << 8) | report.Bytes[2];	//create a 16bit value

	return result;

}
void CHumTempDlg::OnBnClickedStart()
{

	ioHandle = NULL;
	ioHandle = IowKitOpenDevice();	//open IO-Warrior

	if(ioHandle != NULL){

		IOWKIT_SPECIAL_REPORT report;
		memset(&report, 0x00, IOWKIT_SPECIAL_REPORT_SIZE);

		report.ReportID = 0x01; //I2C-Mode
		report.Bytes[0] = 0x01; //Enable
		report.Bytes[1] = 0xC0; //Disable Pull-Up resistors, Enable Bus

		IowKitWrite(ioHandle, IOW_PIPE_SPECIAL_MODE, (char*) &report, IOWKIT_SPECIAL_REPORT_SIZE);

		SetTimer(IDC_LOOPTIME, 1000, NULL);		//start timer with 1 secound timing (min 0.8s to avoid heating up SHTxx)

	}
}

//----------------------------------------------------------------------------------------
// calculates temperature [�C] and humidity [%RH] 
// input :  humi [Ticks] (12 bit) 
//          temp [Ticks] (14 bit)
// output:  humi [%RH]
//          temp [�C]
void CHumTempDlg::CalcTRH(float *humidity, float *temperature)
{
  const float C1 = -4.0;              // for 12 Bit
  const float C2 = +0.0405;           // for 12 Bit
  const float C3 = -0.0000028;        // for 12 Bit
  const float T1 = +0.01;             // for 14 Bit @ 5V
  const float T2 = +0.00008;           // for 14 Bit @ 5V	

  float rh = *humidity;					// rh:      Humidity [Ticks] 12 Bit 
  float t = *temperature;				// t:       Temperature [Ticks] 14 Bit
  float rh_lin;							// rh_lin:  Humidity linear
  float rh_true;						// rh_true: Temperature compensated humidity
  float t_C;							// t_C   :  Temperature [�C]

  t_C = t*0.01 - 40;						//calc. temperature from ticks to [�C]
  rh_lin = C3*rh*rh + C2*rh + C1;			//calc. humidity from ticks to [%RH]
  rh_true = (t_C-25)*(T1+T2*rh)+rh_lin;		//calc. temperature compensated humidity [%RH]
  
  if(rh_true>100) rh_true = 100;		//cut if the value is outside of
  if(rh_true<0.1) rh_true = 0.1;		//the physical possible range


  *temperature = t_C;		//return temperature [�C]
  *humidity = rh_true;		//return humidity[%RH]
}

//--------------------------------------------------------------------
// calculates dew point
// input:   humidity [%RH], temperature [�C]
// output:  dew point [�C]
float CHumTempDlg::calc_dewpoint(float h,float t)
{ 
	float logEx,dew_point;
	logEx = 0.66077 + 7.5 * t / (237.3+t) + (log10(h) - 2);
	dew_point = (logEx - 0.66077) * 237.3 / (0.66077+7.5-logEx);
  
	return dew_point;
}