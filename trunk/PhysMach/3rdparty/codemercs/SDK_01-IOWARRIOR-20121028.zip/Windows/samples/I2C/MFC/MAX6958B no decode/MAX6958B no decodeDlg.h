// MAX6958B no decodeDlg.h : header file
//

#pragma once
#include "iowkit.h"
#include "afxwin.h"


// CMAX6958BnodecodeDlg dialog
class CMAX6958BnodecodeDlg : public CDialog
{
// Construction
public:
	CMAX6958BnodecodeDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_MAX6958BNODECODE_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	BOOL m_a;
	BOOL m_b;
	BOOL m_c;
	BOOL m_d;
	BOOL m_e;
	BOOL m_f;
	BOOL m_g;
	int m_value;
public:
	IOWKIT_HANDLE iowHandle;
    ULONG Pid;
    void SendReport(IOWKIT56_SPECIAL_REPORT *report);
public:
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBnClickedClear();
	afx_msg void OnBnClickedTest();
	afx_msg void OnBnClickedSend();
	void SendValue(int display);
	afx_msg void OnBnClickedSegment1();
	afx_msg void OnBnClickedSegment2();
	afx_msg void OnBnClickedSegment3();
	afx_msg void OnBnClickedSegment4();
	afx_msg void OnBnClickedClearbuttons();
    afx_msg void OnClose();
};
