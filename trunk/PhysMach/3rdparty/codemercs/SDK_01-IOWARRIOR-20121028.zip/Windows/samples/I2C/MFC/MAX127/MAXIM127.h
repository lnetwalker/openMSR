// MAXIM127.h : Haupt-Header-Datei f�r die Anwendung MAXIM127
//

#if !defined(AFX_MAXIM127_H__D5641791_1723_4E6E_B2CA_2AC1C5FCECE4__INCLUDED_)
#define AFX_MAXIM127_H__D5641791_1723_4E6E_B2CA_2AC1C5FCECE4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// Hauptsymbole

/////////////////////////////////////////////////////////////////////////////
// CMAXIM127App:
// Siehe MAXIM127.cpp f�r die Implementierung dieser Klasse
//

class CMAXIM127App : public CWinApp
{
public:
	CMAXIM127App();

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CMAXIM127App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementierung

	//{{AFX_MSG(CMAXIM127App)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_MAXIM127_H__D5641791_1723_4E6E_B2CA_2AC1C5FCECE4__INCLUDED_)
