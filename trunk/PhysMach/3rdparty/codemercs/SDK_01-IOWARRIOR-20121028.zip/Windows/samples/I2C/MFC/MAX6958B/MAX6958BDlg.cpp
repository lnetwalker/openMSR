// MAX6958BDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MAX6958B.h"
#include "MAX6958BDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMAX6958BDlg dialog

CMAX6958BDlg::CMAX6958BDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CMAX6958BDlg::IDD, pParent)
    , m_value(_T(""))
    , m_test(FALSE)
    , m_slider(0)
    , m_onoff(TRUE) //Set checkbox selected
    , m_light(0)
{
    m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMAX6958BDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    DDX_Text(pDX, IDC_VALUE, m_value);
    DDX_Check(pDX, IDC_TEST, m_test);
    DDX_Control(pDX, IDC_REPORT, m_reportlist);
    DDX_Slider(pDX, IDC_BRIGHTNESS2, m_slider);
    DDX_Control(pDX, IDC_BRIGHTNESS2, m_sliderctrl);
    DDX_Check(pDX, IDC_ONOFF, m_onoff);
    DDX_Text(pDX, IDC_BRIGHTLEVEL, m_light);
}

BEGIN_MESSAGE_MAP(CMAX6958BDlg, CDialog)
    ON_WM_PAINT()
    ON_WM_QUERYDRAGICON()
    //}}AFX_MSG_MAP
    ON_BN_CLICKED(IDC_TEST, &CMAX6958BDlg::OnBnClickedTest)
    ON_BN_CLICKED(IDC_RESET, &CMAX6958BDlg::OnBnClickedReset)
    ON_BN_CLICKED(IDC_SEND, &CMAX6958BDlg::OnBnClickedSend)
    ON_BN_CLICKED(IDC_CLEAR, &CMAX6958BDlg::OnBnClickedClear)
    ON_BN_CLICKED(IDC_ONOFF, &CMAX6958BDlg::OnBnClickedOnoff)
    ON_NOTIFY(NM_CUSTOMDRAW, IDC_BRIGHTNESS2, &CMAX6958BDlg::OnNMCustomdrawBrightness2)
    ON_WM_CLOSE()
END_MESSAGE_MAP()


// CMAX6958BDlg message handlers

BOOL CMAX6958BDlg::OnInitDialog()
{
    CDialog::OnInitDialog();

    // Set the icon for this dialog.  The framework does this automatically
    //  when the application's main window is not a dialog
    SetIcon(m_hIcon, TRUE);			// Set big icon
    SetIcon(m_hIcon, FALSE);		// Set small icon

    // TODO: Add extra initialization here
    WCHAR sn[16];
    CString found;

    iowHandle = IowKitOpenDevice();
    IowKitGetSerialNumber(iowHandle, sn);
    Pid = IowKitGetProductId(iowHandle);

    switch(Pid)
    {
        case IOWKIT_PID_IOW40:
            found.Format("IOWarrior 40 found - SN: %S", sn);
            m_reportlist.InsertString(0, found);
            break;

        case IOWKIT_PID_IOW24:
            found.Format("IOWarrior 24 found - SN: %S", sn);
            m_reportlist.InsertString(0, found);
            break;

        case IOWKIT_PID_IOW56:
            found.Format("IOWarrior 56 found - SN: %S", sn);
            m_reportlist.InsertString(0, found);
            break;
    }

    if(iowHandle != NULL)
    {
        IOWKIT56_SPECIAL_REPORT report;

        memset(&report, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
        report.ReportID = 0x01; // Choose IIC-Mode
        report.Bytes[0] = 0x01; // Enable IIC-Mode
        if (Pid == IOWKIT_PID_IOW56)
          report.Bytes[1] = 0x02; // IIC Speed 50kHz
        SendReport(&report);

        memset(&report, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
        report.ReportID = 0x02; // Enable Write-Mode
        report.Bytes[0] = 0xC3; // Start & Stopbit = 1, 3Bytes will be sent
        report.Bytes[1] = 0x72; // Address of MAX6958B
        report.Bytes[2] = 0x04; // Normal-Mode for MAX6958B
        report.Bytes[3] = 0x01; // Enable Normal-Mode for MAX6958B
        SendReport(&report);

        memset(&report, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
        report.ReportID = 0x02; // Enable Write-Mode
        report.Bytes[0] = 0xC3; // Start & Stopbit = 1, 3Bytes will be sent
        report.Bytes[1] = 0x72; // Address of MAX6958B
        report.Bytes[2] = 0x01; // Decode-Mode for MAX6958B
        report.Bytes[3] = 0x0F; // Enable Decode-Mode for MAX6958B
        SendReport(&report);
    }
    else
    {
        MessageBox("Please connect an IOWarrior and start the program again.", "No IOWarrior found", NULL);
        IowKitCloseDevice(iowHandle);
        OnOK();
    }

    m_sliderctrl.SetRange(0, 63, NULL);
        
    UpdateData(FALSE);

    return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMAX6958BDlg::SendReport(IOWKIT56_SPECIAL_REPORT *report)
{
    switch(Pid)
    {
        case IOWKIT_PID_IOW40:
        case IOWKIT_PID_IOW24:
            IowKitWrite(iowHandle,IOW_PIPE_SPECIAL_MODE, (char *) report, IOWKIT_SPECIAL_REPORT_SIZE);
            break;

        case IOWKIT_PID_IOW56:
            IowKitWrite(iowHandle,IOW_PIPE_SPECIAL_MODE, (char *) report, IOWKIT56_SPECIAL_REPORT_SIZE);
            break;
    }
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMAX6958BDlg::OnPaint()
{
    if (IsIconic())
    {
        CPaintDC dc(this); // device context for painting

        SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

        // Center icon in client rectangle
        int cxIcon = GetSystemMetrics(SM_CXICON);
        int cyIcon = GetSystemMetrics(SM_CYICON);
        CRect rect;
        GetClientRect(&rect);
        int x = (rect.Width() - cxIcon + 1) / 2;
        int y = (rect.Height() - cyIcon + 1) / 2;

        // Draw the icon
        dc.DrawIcon(x, y, m_hIcon);
    }
    else
    {
        CDialog::OnPaint();
    }
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMAX6958BDlg::OnQueryDragIcon()
{
    return static_cast<HCURSOR>(m_hIcon);
}


void CMAX6958BDlg::OnBnClickedTest()
{
    IOWKIT56_SPECIAL_REPORT report;

    //Run command 'Test' to see if all LED are functional
    UpdateData(TRUE);
    memset(&report, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
    report.ReportID = 0x02; // Enable write-mode
    report.Bytes[0] = 0xC3; // Start & stopbit = 1, 3 bytes will be send
    report.Bytes[1] = 0x72; // Address of MAX6958B
    report.Bytes[2] = 0x07; // Command for testing

    //Enable test
    if(m_test != NULL)
    {
        report.Bytes[3] = 0x01;
        m_reportlist.InsertString(0, "Testing segments");
    }
    else
        report.Bytes[3] = 0x00;

    SendReport(&report);

    UpdateData(FALSE);
}

void CMAX6958BDlg::OnBnClickedReset()
{
    IOWKIT56_SPECIAL_REPORT report;
    int seg = 32; //Position of the 1st 7-Segment-Display

    //Reset the 7-Segment-Display to '0000'
    memset(&report, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
    report.ReportID = 0x02;
    report.Bytes[0] = 0xC3;
    report.Bytes[1] = 0x72;

    for(int i = 0; i < 4; i++, seg++)
    {
        report.Bytes[2] = seg;
        report.Bytes[3] = 0x00;

        SendReport(&report);
    }
    m_reportlist.InsertString(0,"Reset segments to '0000'");
    m_value = "0000";
    UpdateData(FALSE);
}

void CMAX6958BDlg::OnBnClickedSend()
{
    IOWKIT56_SPECIAL_REPORT report;
    int c;
    int length;
    int seg = 32;
    CString chars;
    CString replist;
    CString temp;

    UpdateData(TRUE);

    //Get length for error-handling
    length = m_value.GetLength();
    temp = m_value;

    //Check the length of m_value and execute error-handling
    if(length >= 5) m_value = m_value.Mid(0, 4);
    if(length == 3) m_value.Format("0%s", temp);
    if(length == 2) m_value.Format("00%s", temp);
    if(length == 1) m_value.Format("000%s", temp);
    if(length == 0) m_value = "0000";

    //One or more chars in value are not supported
    int iPos = m_value.FindOneOf("GHIJKLMNOPQRSTUVWXYZ����,.;:-_+#*'!�$%&/()=?{[]}\\<>|�@�^�");
    if (iPos > -1)
    {
        m_value = "0000";
        m_reportlist.InsertString(0, "Unknown values found. Sending '0000'");
    }

    memset(&report, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
    report.ReportID = 0x02;
    report.Bytes[0] = 0xC3;
    report.Bytes[1] = 0x72;

    //Check the value for hexadezimal
    for(int i = 0; i < 4; i++, seg++)
    {
        if(m_value.GetAt(i) >= 0 || m_value.GetAt(i) <= 9) c = (int) m_value.GetAt(i);
        if(m_value.GetAt(i) == 'A') c = 10;
        if(m_value.GetAt(i) == 'B') c = 11;
        if(m_value.GetAt(i) == 'C') c = 12;
        if(m_value.GetAt(i) == 'D') c = 13;
        if(m_value.GetAt(i) == 'E') c = 14;
        if(m_value.GetAt(i) == 'F') c = 15;

        report.Bytes[2] = seg;
        report.Bytes[3] = c;

        SendReport(&report);
    }

    //Insert String into reportlist
    replist.Format("Sending data '%s'", m_value);
    m_reportlist.InsertString(0, replist);

    UpdateData(FALSE);
}

void CMAX6958BDlg::OnBnClickedClear()
{
    UpdateData(TRUE);
    m_reportlist.ResetContent();
    UpdateData(FALSE);
}

void CMAX6958BDlg::OnBnClickedOnoff()
{
    IOWKIT56_SPECIAL_REPORT report;

    //Run commando 'shutdown / normal' for OFF or ON
    UpdateData(TRUE);

    memset(&report, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
    report.ReportID = 0x02; // Enable write-mode
    report.Bytes[0] = 0xC3; // Start & stopbit = 1, 3 bytes will be send
    report.Bytes[1] = 0x72; // Address of MAX6958B
    report.Bytes[2] = 0x04; // Command for testing

    //Enable test
    if(m_onoff != NULL)
    {
        report.Bytes[3] = 0x01; //ON
        m_reportlist.InsertString(0,"Segments 'ON'");
    }
    else
    {
        report.Bytes[3] = 0x00; //OFF
        m_reportlist.InsertString(0,"Segments 'OFF'");
    }

    SendReport(&report);

    UpdateData(FALSE);
}

void CMAX6958BDlg::OnNMCustomdrawBrightness2(NMHDR *pNMHDR, LRESULT *pResult)
{
    LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);
    IOWKIT56_SPECIAL_REPORT report;
    CString replist;

    //Set a brightness-level
    UpdateData(TRUE);

    memset(&report, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
    report.ReportID = 0x02; // Enable write-mode
    report.Bytes[0] = 0xC3; // Start & stopbit = 1, 3 bytes will be send
    report.Bytes[1] = 0x72; // Address of MAX6958B
    report.Bytes[2] = 0x02; // Command for brightness
    
    // Set the level of brightness (0...63)
    // All values and mA in MAX6958 Datasheet
    report.Bytes[3] = m_slider;

    SendReport(&report);

    m_light = m_slider;

    UpdateData(FALSE);

    *pResult = 0;
}

void CMAX6958BDlg::OnClose()
{
    if(iowHandle != NULL)
    {
        IOWKIT56_SPECIAL_REPORT report;

        memset(&report, 0, IOWKIT56_SPECIAL_REPORT_SIZE);
        report.ReportID = 0x01; // Choose IIC-Mode
        report.Bytes[0] = 0x00; // Disable IIC-Mode
        SendReport(&report);
    }
    IowKitCloseDevice(iowHandle);

    CDialog::OnClose();
}
