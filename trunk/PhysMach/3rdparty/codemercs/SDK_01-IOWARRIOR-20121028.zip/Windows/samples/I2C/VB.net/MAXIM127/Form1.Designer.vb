<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class Form1
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents Timer1 As System.Windows.Forms.Timer
	Public WithEvents Image1 As System.Windows.Forms.PictureBox
	Public WithEvents _Label1_8 As System.Windows.Forms.Label
	Public WithEvents _Values_0 As System.Windows.Forms.Label
	Public WithEvents _Values_1 As System.Windows.Forms.Label
	Public WithEvents _Label1_0 As System.Windows.Forms.Label
	Public WithEvents _Label2_7 As System.Windows.Forms.Label
	Public WithEvents _Label2_6 As System.Windows.Forms.Label
	Public WithEvents _Label2_5 As System.Windows.Forms.Label
	Public WithEvents _Label2_4 As System.Windows.Forms.Label
	Public WithEvents _Label2_3 As System.Windows.Forms.Label
	Public WithEvents _Label2_2 As System.Windows.Forms.Label
	Public WithEvents _Label2_1 As System.Windows.Forms.Label
	Public WithEvents _Label2_0 As System.Windows.Forms.Label
	Public WithEvents _Label1_7 As System.Windows.Forms.Label
	Public WithEvents _Label1_6 As System.Windows.Forms.Label
	Public WithEvents _Label1_5 As System.Windows.Forms.Label
	Public WithEvents _Label1_4 As System.Windows.Forms.Label
	Public WithEvents _Label1_3 As System.Windows.Forms.Label
	Public WithEvents _Label1_2 As System.Windows.Forms.Label
	Public WithEvents _Label1_1 As System.Windows.Forms.Label
	Public WithEvents _Values_7 As System.Windows.Forms.Label
	Public WithEvents _Values_6 As System.Windows.Forms.Label
	Public WithEvents _Values_5 As System.Windows.Forms.Label
	Public WithEvents _Values_4 As System.Windows.Forms.Label
	Public WithEvents _Values_3 As System.Windows.Forms.Label
	Public WithEvents _Values_2 As System.Windows.Forms.Label
	Public WithEvents Label1 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	Public WithEvents Label2 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	Public WithEvents Values As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.Timer1 = New System.Windows.Forms.Timer(components)
		Me.Image1 = New System.Windows.Forms.PictureBox
		Me._Label1_8 = New System.Windows.Forms.Label
		Me._Values_0 = New System.Windows.Forms.Label
		Me._Values_1 = New System.Windows.Forms.Label
		Me._Label1_0 = New System.Windows.Forms.Label
		Me._Label2_7 = New System.Windows.Forms.Label
		Me._Label2_6 = New System.Windows.Forms.Label
		Me._Label2_5 = New System.Windows.Forms.Label
		Me._Label2_4 = New System.Windows.Forms.Label
		Me._Label2_3 = New System.Windows.Forms.Label
		Me._Label2_2 = New System.Windows.Forms.Label
		Me._Label2_1 = New System.Windows.Forms.Label
		Me._Label2_0 = New System.Windows.Forms.Label
		Me._Label1_7 = New System.Windows.Forms.Label
		Me._Label1_6 = New System.Windows.Forms.Label
		Me._Label1_5 = New System.Windows.Forms.Label
		Me._Label1_4 = New System.Windows.Forms.Label
		Me._Label1_3 = New System.Windows.Forms.Label
		Me._Label1_2 = New System.Windows.Forms.Label
		Me._Label1_1 = New System.Windows.Forms.Label
		Me._Values_7 = New System.Windows.Forms.Label
		Me._Values_6 = New System.Windows.Forms.Label
		Me._Values_5 = New System.Windows.Forms.Label
		Me._Values_4 = New System.Windows.Forms.Label
		Me._Values_3 = New System.Windows.Forms.Label
		Me._Values_2 = New System.Windows.Forms.Label
		Me.Label1 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(components)
		Me.Label2 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(components)
		Me.Values = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(components)
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		CType(Me.Label1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.Label2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.Values, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
		Me.Text = "MAXIM 127 IIC Voltage"
		Me.ClientSize = New System.Drawing.Size(194, 285)
		Me.Location = New System.Drawing.Point(3, 29)
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.ControlBox = True
		Me.Enabled = True
		Me.KeyPreview = False
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "Form1"
		Me.Timer1.Enabled = False
		Me.Timer1.Interval = 200
		Me.Image1.Size = New System.Drawing.Size(99, 45)
		Me.Image1.Location = New System.Drawing.Point(48, 232)
		Me.Image1.Image = CType(resources.GetObject("Image1.Image"), System.Drawing.Image)
		Me.Image1.Enabled = True
		Me.Image1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Image1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Normal
		Me.Image1.Visible = True
		Me.Image1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Image1.Name = "Image1"
		Me._Label1_8.Text = "Supports IOWarrior 24, 40"
		Me._Label1_8.Size = New System.Drawing.Size(123, 13)
		Me._Label1_8.Location = New System.Drawing.Point(36, 8)
		Me._Label1_8.TabIndex = 24
		Me._Label1_8.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_8.BackColor = System.Drawing.SystemColors.Control
		Me._Label1_8.Enabled = True
		Me._Label1_8.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label1_8.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_8.UseMnemonic = True
		Me._Label1_8.Visible = True
		Me._Label1_8.AutoSize = True
		Me._Label1_8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_8.Name = "_Label1_8"
		Me._Values_0.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me._Values_0.Size = New System.Drawing.Size(88, 13)
		Me._Values_0.Location = New System.Drawing.Point(56, 40)
		Me._Values_0.TabIndex = 23
		Me._Values_0.BackColor = System.Drawing.SystemColors.Control
		Me._Values_0.Enabled = True
		Me._Values_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Values_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._Values_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Values_0.UseMnemonic = True
		Me._Values_0.Visible = True
		Me._Values_0.AutoSize = False
		Me._Values_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Values_0.Name = "_Values_0"
		Me._Values_1.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me._Values_1.Size = New System.Drawing.Size(88, 13)
		Me._Values_1.Location = New System.Drawing.Point(56, 64)
		Me._Values_1.TabIndex = 22
		Me._Values_1.BackColor = System.Drawing.SystemColors.Control
		Me._Values_1.Enabled = True
		Me._Values_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Values_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._Values_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Values_1.UseMnemonic = True
		Me._Values_1.Visible = True
		Me._Values_1.AutoSize = False
		Me._Values_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Values_1.Name = "_Values_1"
		Me._Label1_0.Text = "V"
		Me._Label1_0.Size = New System.Drawing.Size(7, 13)
		Me._Label1_0.Location = New System.Drawing.Point(160, 40)
		Me._Label1_0.TabIndex = 21
		Me._Label1_0.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_0.BackColor = System.Drawing.SystemColors.Control
		Me._Label1_0.Enabled = True
		Me._Label1_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_0.UseMnemonic = True
		Me._Label1_0.Visible = True
		Me._Label1_0.AutoSize = True
		Me._Label1_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_0.Name = "_Label1_0"
		Me._Label2_7.Text = "CH7:"
		Me._Label2_7.Size = New System.Drawing.Size(24, 13)
		Me._Label2_7.Location = New System.Drawing.Point(24, 208)
		Me._Label2_7.TabIndex = 20
		Me._Label2_7.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label2_7.BackColor = System.Drawing.SystemColors.Control
		Me._Label2_7.Enabled = True
		Me._Label2_7.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label2_7.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label2_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label2_7.UseMnemonic = True
		Me._Label2_7.Visible = True
		Me._Label2_7.AutoSize = True
		Me._Label2_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label2_7.Name = "_Label2_7"
		Me._Label2_6.Text = "CH6:"
		Me._Label2_6.Size = New System.Drawing.Size(24, 13)
		Me._Label2_6.Location = New System.Drawing.Point(24, 184)
		Me._Label2_6.TabIndex = 19
		Me._Label2_6.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label2_6.BackColor = System.Drawing.SystemColors.Control
		Me._Label2_6.Enabled = True
		Me._Label2_6.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label2_6.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label2_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label2_6.UseMnemonic = True
		Me._Label2_6.Visible = True
		Me._Label2_6.AutoSize = True
		Me._Label2_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label2_6.Name = "_Label2_6"
		Me._Label2_5.Text = "CH5:"
		Me._Label2_5.Size = New System.Drawing.Size(24, 13)
		Me._Label2_5.Location = New System.Drawing.Point(24, 160)
		Me._Label2_5.TabIndex = 18
		Me._Label2_5.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label2_5.BackColor = System.Drawing.SystemColors.Control
		Me._Label2_5.Enabled = True
		Me._Label2_5.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label2_5.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label2_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label2_5.UseMnemonic = True
		Me._Label2_5.Visible = True
		Me._Label2_5.AutoSize = True
		Me._Label2_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label2_5.Name = "_Label2_5"
		Me._Label2_4.Text = "CH4:"
		Me._Label2_4.Size = New System.Drawing.Size(24, 13)
		Me._Label2_4.Location = New System.Drawing.Point(24, 136)
		Me._Label2_4.TabIndex = 17
		Me._Label2_4.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label2_4.BackColor = System.Drawing.SystemColors.Control
		Me._Label2_4.Enabled = True
		Me._Label2_4.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label2_4.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label2_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label2_4.UseMnemonic = True
		Me._Label2_4.Visible = True
		Me._Label2_4.AutoSize = True
		Me._Label2_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label2_4.Name = "_Label2_4"
		Me._Label2_3.Text = "CH3:"
		Me._Label2_3.Size = New System.Drawing.Size(24, 13)
		Me._Label2_3.Location = New System.Drawing.Point(24, 112)
		Me._Label2_3.TabIndex = 16
		Me._Label2_3.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label2_3.BackColor = System.Drawing.SystemColors.Control
		Me._Label2_3.Enabled = True
		Me._Label2_3.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label2_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label2_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label2_3.UseMnemonic = True
		Me._Label2_3.Visible = True
		Me._Label2_3.AutoSize = True
		Me._Label2_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label2_3.Name = "_Label2_3"
		Me._Label2_2.Text = "CH2:"
		Me._Label2_2.Size = New System.Drawing.Size(24, 13)
		Me._Label2_2.Location = New System.Drawing.Point(24, 88)
		Me._Label2_2.TabIndex = 15
		Me._Label2_2.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label2_2.BackColor = System.Drawing.SystemColors.Control
		Me._Label2_2.Enabled = True
		Me._Label2_2.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label2_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label2_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label2_2.UseMnemonic = True
		Me._Label2_2.Visible = True
		Me._Label2_2.AutoSize = True
		Me._Label2_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label2_2.Name = "_Label2_2"
		Me._Label2_1.Text = "CH1:"
		Me._Label2_1.Size = New System.Drawing.Size(24, 13)
		Me._Label2_1.Location = New System.Drawing.Point(24, 64)
		Me._Label2_1.TabIndex = 14
		Me._Label2_1.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label2_1.BackColor = System.Drawing.SystemColors.Control
		Me._Label2_1.Enabled = True
		Me._Label2_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label2_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label2_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label2_1.UseMnemonic = True
		Me._Label2_1.Visible = True
		Me._Label2_1.AutoSize = True
		Me._Label2_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label2_1.Name = "_Label2_1"
		Me._Label2_0.Text = "CH0:"
		Me._Label2_0.Size = New System.Drawing.Size(24, 13)
		Me._Label2_0.Location = New System.Drawing.Point(24, 40)
		Me._Label2_0.TabIndex = 13
		Me._Label2_0.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label2_0.BackColor = System.Drawing.SystemColors.Control
		Me._Label2_0.Enabled = True
		Me._Label2_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label2_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label2_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label2_0.UseMnemonic = True
		Me._Label2_0.Visible = True
		Me._Label2_0.AutoSize = True
		Me._Label2_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label2_0.Name = "_Label2_0"
		Me._Label1_7.Text = "V"
		Me._Label1_7.Size = New System.Drawing.Size(7, 13)
		Me._Label1_7.Location = New System.Drawing.Point(160, 208)
		Me._Label1_7.TabIndex = 12
		Me._Label1_7.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_7.BackColor = System.Drawing.SystemColors.Control
		Me._Label1_7.Enabled = True
		Me._Label1_7.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label1_7.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_7.UseMnemonic = True
		Me._Label1_7.Visible = True
		Me._Label1_7.AutoSize = True
		Me._Label1_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_7.Name = "_Label1_7"
		Me._Label1_6.Text = "V"
		Me._Label1_6.Size = New System.Drawing.Size(7, 13)
		Me._Label1_6.Location = New System.Drawing.Point(160, 184)
		Me._Label1_6.TabIndex = 11
		Me._Label1_6.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_6.BackColor = System.Drawing.SystemColors.Control
		Me._Label1_6.Enabled = True
		Me._Label1_6.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label1_6.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_6.UseMnemonic = True
		Me._Label1_6.Visible = True
		Me._Label1_6.AutoSize = True
		Me._Label1_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_6.Name = "_Label1_6"
		Me._Label1_5.Text = "V"
		Me._Label1_5.Size = New System.Drawing.Size(7, 13)
		Me._Label1_5.Location = New System.Drawing.Point(160, 160)
		Me._Label1_5.TabIndex = 10
		Me._Label1_5.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_5.BackColor = System.Drawing.SystemColors.Control
		Me._Label1_5.Enabled = True
		Me._Label1_5.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label1_5.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_5.UseMnemonic = True
		Me._Label1_5.Visible = True
		Me._Label1_5.AutoSize = True
		Me._Label1_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_5.Name = "_Label1_5"
		Me._Label1_4.Text = "V"
		Me._Label1_4.Size = New System.Drawing.Size(7, 13)
		Me._Label1_4.Location = New System.Drawing.Point(160, 136)
		Me._Label1_4.TabIndex = 9
		Me._Label1_4.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_4.BackColor = System.Drawing.SystemColors.Control
		Me._Label1_4.Enabled = True
		Me._Label1_4.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label1_4.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_4.UseMnemonic = True
		Me._Label1_4.Visible = True
		Me._Label1_4.AutoSize = True
		Me._Label1_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_4.Name = "_Label1_4"
		Me._Label1_3.Text = "V"
		Me._Label1_3.Size = New System.Drawing.Size(7, 13)
		Me._Label1_3.Location = New System.Drawing.Point(160, 112)
		Me._Label1_3.TabIndex = 8
		Me._Label1_3.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_3.BackColor = System.Drawing.SystemColors.Control
		Me._Label1_3.Enabled = True
		Me._Label1_3.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label1_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_3.UseMnemonic = True
		Me._Label1_3.Visible = True
		Me._Label1_3.AutoSize = True
		Me._Label1_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_3.Name = "_Label1_3"
		Me._Label1_2.Text = "V"
		Me._Label1_2.Size = New System.Drawing.Size(7, 13)
		Me._Label1_2.Location = New System.Drawing.Point(160, 88)
		Me._Label1_2.TabIndex = 7
		Me._Label1_2.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_2.BackColor = System.Drawing.SystemColors.Control
		Me._Label1_2.Enabled = True
		Me._Label1_2.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label1_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_2.UseMnemonic = True
		Me._Label1_2.Visible = True
		Me._Label1_2.AutoSize = True
		Me._Label1_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_2.Name = "_Label1_2"
		Me._Label1_1.Text = "V"
		Me._Label1_1.Size = New System.Drawing.Size(7, 13)
		Me._Label1_1.Location = New System.Drawing.Point(160, 64)
		Me._Label1_1.TabIndex = 6
		Me._Label1_1.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label1_1.BackColor = System.Drawing.SystemColors.Control
		Me._Label1_1.Enabled = True
		Me._Label1_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label1_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label1_1.UseMnemonic = True
		Me._Label1_1.Visible = True
		Me._Label1_1.AutoSize = True
		Me._Label1_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label1_1.Name = "_Label1_1"
		Me._Values_7.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me._Values_7.Size = New System.Drawing.Size(88, 13)
		Me._Values_7.Location = New System.Drawing.Point(56, 208)
		Me._Values_7.TabIndex = 5
		Me._Values_7.BackColor = System.Drawing.SystemColors.Control
		Me._Values_7.Enabled = True
		Me._Values_7.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Values_7.Cursor = System.Windows.Forms.Cursors.Default
		Me._Values_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Values_7.UseMnemonic = True
		Me._Values_7.Visible = True
		Me._Values_7.AutoSize = False
		Me._Values_7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Values_7.Name = "_Values_7"
		Me._Values_6.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me._Values_6.Size = New System.Drawing.Size(88, 13)
		Me._Values_6.Location = New System.Drawing.Point(56, 184)
		Me._Values_6.TabIndex = 4
		Me._Values_6.BackColor = System.Drawing.SystemColors.Control
		Me._Values_6.Enabled = True
		Me._Values_6.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Values_6.Cursor = System.Windows.Forms.Cursors.Default
		Me._Values_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Values_6.UseMnemonic = True
		Me._Values_6.Visible = True
		Me._Values_6.AutoSize = False
		Me._Values_6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Values_6.Name = "_Values_6"
		Me._Values_5.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me._Values_5.Size = New System.Drawing.Size(88, 13)
		Me._Values_5.Location = New System.Drawing.Point(56, 160)
		Me._Values_5.TabIndex = 3
		Me._Values_5.BackColor = System.Drawing.SystemColors.Control
		Me._Values_5.Enabled = True
		Me._Values_5.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Values_5.Cursor = System.Windows.Forms.Cursors.Default
		Me._Values_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Values_5.UseMnemonic = True
		Me._Values_5.Visible = True
		Me._Values_5.AutoSize = False
		Me._Values_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Values_5.Name = "_Values_5"
		Me._Values_4.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me._Values_4.Size = New System.Drawing.Size(88, 13)
		Me._Values_4.Location = New System.Drawing.Point(56, 136)
		Me._Values_4.TabIndex = 2
		Me._Values_4.BackColor = System.Drawing.SystemColors.Control
		Me._Values_4.Enabled = True
		Me._Values_4.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Values_4.Cursor = System.Windows.Forms.Cursors.Default
		Me._Values_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Values_4.UseMnemonic = True
		Me._Values_4.Visible = True
		Me._Values_4.AutoSize = False
		Me._Values_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Values_4.Name = "_Values_4"
		Me._Values_3.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me._Values_3.Size = New System.Drawing.Size(88, 13)
		Me._Values_3.Location = New System.Drawing.Point(56, 112)
		Me._Values_3.TabIndex = 1
		Me._Values_3.BackColor = System.Drawing.SystemColors.Control
		Me._Values_3.Enabled = True
		Me._Values_3.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Values_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._Values_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Values_3.UseMnemonic = True
		Me._Values_3.Visible = True
		Me._Values_3.AutoSize = False
		Me._Values_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Values_3.Name = "_Values_3"
		Me._Values_2.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me._Values_2.Size = New System.Drawing.Size(88, 13)
		Me._Values_2.Location = New System.Drawing.Point(56, 88)
		Me._Values_2.TabIndex = 0
		Me._Values_2.BackColor = System.Drawing.SystemColors.Control
		Me._Values_2.Enabled = True
		Me._Values_2.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Values_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._Values_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Values_2.UseMnemonic = True
		Me._Values_2.Visible = True
		Me._Values_2.AutoSize = False
		Me._Values_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Values_2.Name = "_Values_2"
		Me.Controls.Add(Image1)
		Me.Controls.Add(_Label1_8)
		Me.Controls.Add(_Values_0)
		Me.Controls.Add(_Values_1)
		Me.Controls.Add(_Label1_0)
		Me.Controls.Add(_Label2_7)
		Me.Controls.Add(_Label2_6)
		Me.Controls.Add(_Label2_5)
		Me.Controls.Add(_Label2_4)
		Me.Controls.Add(_Label2_3)
		Me.Controls.Add(_Label2_2)
		Me.Controls.Add(_Label2_1)
		Me.Controls.Add(_Label2_0)
		Me.Controls.Add(_Label1_7)
		Me.Controls.Add(_Label1_6)
		Me.Controls.Add(_Label1_5)
		Me.Controls.Add(_Label1_4)
		Me.Controls.Add(_Label1_3)
		Me.Controls.Add(_Label1_2)
		Me.Controls.Add(_Label1_1)
		Me.Controls.Add(_Values_7)
		Me.Controls.Add(_Values_6)
		Me.Controls.Add(_Values_5)
		Me.Controls.Add(_Values_4)
		Me.Controls.Add(_Values_3)
		Me.Controls.Add(_Values_2)
		Me.Label1.SetIndex(_Label1_8, CType(8, Short))
		Me.Label1.SetIndex(_Label1_0, CType(0, Short))
		Me.Label1.SetIndex(_Label1_7, CType(7, Short))
		Me.Label1.SetIndex(_Label1_6, CType(6, Short))
		Me.Label1.SetIndex(_Label1_5, CType(5, Short))
		Me.Label1.SetIndex(_Label1_4, CType(4, Short))
		Me.Label1.SetIndex(_Label1_3, CType(3, Short))
		Me.Label1.SetIndex(_Label1_2, CType(2, Short))
		Me.Label1.SetIndex(_Label1_1, CType(1, Short))
		Me.Label2.SetIndex(_Label2_7, CType(7, Short))
		Me.Label2.SetIndex(_Label2_6, CType(6, Short))
		Me.Label2.SetIndex(_Label2_5, CType(5, Short))
		Me.Label2.SetIndex(_Label2_4, CType(4, Short))
		Me.Label2.SetIndex(_Label2_3, CType(3, Short))
		Me.Label2.SetIndex(_Label2_2, CType(2, Short))
		Me.Label2.SetIndex(_Label2_1, CType(1, Short))
		Me.Label2.SetIndex(_Label2_0, CType(0, Short))
		Me.Values.SetIndex(_Values_0, CType(0, Short))
		Me.Values.SetIndex(_Values_1, CType(1, Short))
		Me.Values.SetIndex(_Values_7, CType(7, Short))
		Me.Values.SetIndex(_Values_6, CType(6, Short))
		Me.Values.SetIndex(_Values_5, CType(5, Short))
		Me.Values.SetIndex(_Values_4, CType(4, Short))
		Me.Values.SetIndex(_Values_3, CType(3, Short))
		Me.Values.SetIndex(_Values_2, CType(2, Short))
		CType(Me.Values, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Label2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Label1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class