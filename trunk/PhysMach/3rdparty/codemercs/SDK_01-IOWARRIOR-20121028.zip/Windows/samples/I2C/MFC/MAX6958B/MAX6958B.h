// MAX6958B.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// CMAX6958BApp:
// See MAX6958B.cpp for the implementation of this class
//

class CMAX6958BApp : public CWinApp
{
public:
	CMAX6958BApp();

// Overrides
	public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CMAX6958BApp theApp;