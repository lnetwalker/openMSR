// HumTempDlg.h : Headerdatei
//

#pragma once
#include "iowkit.h"


// CHumTempDlg-Dialogfeld
class CHumTempDlg : public CDialog
{
// Konstruktion
public:
	CHumTempDlg(CWnd* pParent = NULL);	// Standardkonstruktor

// Dialogfelddaten
	enum { IDD = IDD_HUMTEMP_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterst�tzung


// Implementierung
protected:
	HICON m_hIcon;

	// Generierte Funktionen f�r die Meldungstabellen
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnClose();
	afx_msg void OnTimer(UINT_PTR nIDEvent);

	IOWKIT_HANDLE ioHandle;
	short ReadI2C(UCHAR call);
	afx_msg void OnBnClickedStart();
	CFont cFont;
	void CalcTRH(float* humidity, float* temperature);
	float calc_dewpoint(float h,float t);


	float temperature;
	float humidity;
	float dewpoint;
};
