// MAXIM127.cpp : Legt das Klassenverhalten f�r die Anwendung fest.
//

#include "stdafx.h"
#include "MAXIM127.h"
#include "MAXIM127Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMAXIM127App

BEGIN_MESSAGE_MAP(CMAXIM127App, CWinApp)
	//{{AFX_MSG_MAP(CMAXIM127App)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMAXIM127App Konstruktion

CMAXIM127App::CMAXIM127App()
{
}

/////////////////////////////////////////////////////////////////////////////
// Das einzige CMAXIM127App-Objekt

CMAXIM127App theApp;

/////////////////////////////////////////////////////////////////////////////
// CMAXIM127App Initialisierung

BOOL CMAXIM127App::InitInstance()
{
	// Standardinitialisierung

#ifdef _AFXDLL
	Enable3dControls();			// Diese Funktion bei Verwendung von MFC in gemeinsam genutzten DLLs aufrufen
#else
	Enable3dControlsStatic();	// Diese Funktion bei statischen MFC-Anbindungen aufrufen
#endif

	CMAXIM127Dlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	// Da das Dialogfeld geschlossen wurde, FALSE zur�ckliefern, so dass wir die
	//  Anwendung verlassen, anstatt das Nachrichtensystem der Anwendung zu starten.
	return FALSE;
}
