// MAX6958B no decode.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// CMAX6958BnodecodeApp:
// See MAX6958B no decode.cpp for the implementation of this class
//

class CMAX6958BnodecodeApp : public CWinApp
{
public:
	CMAX6958BnodecodeApp();

// Overrides
	public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CMAX6958BnodecodeApp theApp;