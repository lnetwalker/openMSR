//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by KeyMatrix.rc
//
#define IDC_TIMELOOP                    101
#define IDD_KEYMATRIX_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       129
#define IDI_ICON2                       130
#define IDB_BITMAP1                     131
#define IDB_BITMAP2                     132
#define IDC_CONNECT                     1000
#define IDC_CLEAR                       1001
#define IDC_STATIC_STATUS               1002
#define IDC_LIST                        1003
#define IDC_FIELD1                      1004
#define IDC_FIELD2                      1005
#define IDC_FIELD3                      1006
#define IDC_FIELD4                      1007
#define IDC_FIELD5                      1008
#define IDC_FIELD6                      1009
#define IDC_FIELD7                      1010
#define IDC_FIELD8                      1011
#define IDC_FIELD9                      1012
#define IDC_FIELD10                     1013
#define IDC_FIELD11                     1014
#define IDC_FIELD12                     1015
#define IDC_FIELD13                     1016
#define IDC_FIELD14                     1017
#define IDC_FIELD15                     1018
#define IDC_FIELD16                     1019
#define IDC_FIELD17                     1020
#define IDC_FIELD18                     1021
#define IDC_FIELD19                     1022
#define IDC_FIELD20                     1023
#define IDC_FIELD21                     1024
#define IDC_FIELD22                     1025
#define IDC_FIELD23                     1026
#define IDC_FIELD24                     1027
#define IDC_FIELD25                     1028
#define IDC_FIELD26                     1029
#define IDC_FIELD27                     1030
#define IDC_FIELD28                     1031
#define IDC_FIELD29                     1032
#define IDC_FIELD30                     1033
#define IDC_FIELD31                     1034
#define IDC_FIELD32                     1035
#define IDC_FIELD33                     1036
#define IDC_FIELD34                     1037
#define IDC_FIELD35                     1038
#define IDC_FIELD36                     1039
#define IDC_FIELD37                     1040
#define IDC_FIELD38                     1041
#define IDC_FIELD39                     1042
#define IDC_FIELD40                     1043
#define IDC_FIELD41                     1044
#define IDC_FIELD42                     1045
#define IDC_FIELD43                     1046
#define IDC_FIELD44                     1047
#define IDC_FIELD45                     1048
#define IDC_FIELD46                     1049
#define IDC_FIELD47                     1050
#define IDC_FIELD48                     1051
#define IDC_FIELD49                     1052
#define IDC_FIELD50                     1053
#define IDC_FIELD51                     1054
#define IDC_FIELD52                     1055
#define IDC_FIELD53                     1056
#define IDC_FIELD54                     1057
#define IDC_FIELD55                     1058
#define IDC_FIELD56                     1059
#define IDC_FIELD57                     1060
#define IDC_FIELD58                     1061
#define IDC_FIELD59                     1062
#define IDC_FIELD60                     1063
#define IDC_FIELD61                     1064
#define IDC_FIELD62                     1065
#define IDC_FIELD63                     1066
#define IDC_FIELD64                     1067

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
