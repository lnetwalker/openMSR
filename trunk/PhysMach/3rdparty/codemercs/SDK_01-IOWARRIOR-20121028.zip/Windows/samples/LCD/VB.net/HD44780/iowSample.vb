Option Strict Off
Option Explicit On
Friend Class Form1
	Inherits System.Windows.Forms.Form
	' IO-Warrior handle
	Dim iowHandle As Integer
	Dim cursorOn As Boolean
	
	Private Sub CursorLeftBtn_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CursorLeftBtn.Click
		Dim Res As Boolean
		
		' Move cursor to the left
		Res = IowKitCursorLeftLCD(iowHandle)
	End Sub
	
	Private Sub CursorRightBtn_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CursorRightBtn.Click
		Dim Res As Integer
		
		' Move cursor to the right
		Res = IowKitCursorRightLCD(iowHandle)
	End Sub
	
	' Called when program starts and form is loaded
	Private Sub Form1_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Dim Res As Boolean
		
		' Initialize everything
		' Open device
		iowHandle = IowKitOpenDevice()
		' Fail if can't open
		If iowHandle = 0 Then
			' Exit from program
			MsgBox("Can not open device!", 0, "Error")
			End
		End If
		
		' Enable IIC
		Res = IowKitEnableLCD(iowHandle, 1)
		' Check for error
		If Not Res Then
			' Something is wrong, exit
			MsgBox("LCD not present", 0, "Error")
			End
		End If
		' Initialize LCD screen
		Res = IowKitInitLCD(iowHandle, 1)
		' Turn on display, cursor and blinking
		Res = IowKitDispControlLCD(iowHandle, True, True, True)
		' Set cursor movement to right and no shifting
		Res = IowKitEntryModeSet(iowHandle, True, False)
		cursorOn = True
	End Sub
	
	' Called when program exits
	Private Sub Form1_FormClosed(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
		' Disable LCD
		Dim Res As Boolean
		
		Res = IowKitEnableLCD(iowHandle, 0)
		' Close IO-Warrior device
		IowKitCloseDevice((iowHandle))
	End Sub
	
	Private Sub LCDHomeButton_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles LCDHomeButton.Click
		Dim Res As Boolean
		
		' Move cursor to home
		Res = IowKitCursorHomeLCD(iowHandle)
	End Sub
	
	' Readbutton click handler
	Private Sub LCDInitButton_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles LCDInitButton.Click
		Dim Res As Boolean
		
		' Initialize LCD
		Res = IowKitInitLCD(iowHandle, 1)
	End Sub
	
	' Write button click handler
	Private Sub LCDClearButton_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles LCDClearButton.Click
		' Result
		Dim Res As Boolean
		
		' Clear screen
		Res = IowKitClearLCD(iowHandle)
		ReadLabel.Text = "Screen clear"
		ReadLabel.Refresh()
	End Sub
	
	Private Sub LCDWriteButton_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles LCDWriteButton.Click
		Dim Res As Boolean
		
		Res = IowKitWriteStringLCD(iowHandle, (TextVal1.Text))
	End Sub
	
	' Set DDRAM address button handler
	Private Sub SetDRAMAddrButton_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles SetDRAMAddrButton.Click
		Dim Res As Boolean
		Dim Addr As Byte
		
		' Get and convert address
		Addr = Val("&H" & TextVal2.Text)
		' Set DDRAM address
		Res = IowKitSetDDRAMAddr(iowHandle, Addr)
	End Sub
	
	Private Sub ToggleCursorButton_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles ToggleCursorButton.Click
		Dim Res As Boolean
		
		' Toggle cursor on/off
		If cursorOn Then
			Res = IowKitCursorOffLCD(iowHandle)
		Else
			Res = IowKitCursorOnLCD(iowHandle)
		End If
		cursorOn = Not cursorOn
	End Sub
End Class