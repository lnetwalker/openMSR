<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class Form1
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents CursorRightBtn As System.Windows.Forms.Button
	Public WithEvents CursorLeftBtn As System.Windows.Forms.Button
	Public WithEvents ToggleCursorButton As System.Windows.Forms.Button
	Public WithEvents SetDRAMAddrButton As System.Windows.Forms.Button
	Public WithEvents TextVal2 As System.Windows.Forms.TextBox
	Public WithEvents LCDWriteButton As System.Windows.Forms.Button
	Public WithEvents LCDHomeButton As System.Windows.Forms.Button
	Public WithEvents LcdClearButton As System.Windows.Forms.Button
	Public WithEvents LCDInitButton As System.Windows.Forms.Button
	Public WithEvents TextVal1 As System.Windows.Forms.TextBox
	Public WithEvents Image1 As System.Windows.Forms.PictureBox
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents ReadLabel As System.Windows.Forms.Label
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.CursorRightBtn = New System.Windows.Forms.Button
        Me.CursorLeftBtn = New System.Windows.Forms.Button
        Me.ToggleCursorButton = New System.Windows.Forms.Button
        Me.SetDRAMAddrButton = New System.Windows.Forms.Button
        Me.LCDHomeButton = New System.Windows.Forms.Button
        Me.LcdClearButton = New System.Windows.Forms.Button
        Me.LCDInitButton = New System.Windows.Forms.Button
        Me.TextVal2 = New System.Windows.Forms.TextBox
        Me.LCDWriteButton = New System.Windows.Forms.Button
        Me.TextVal1 = New System.Windows.Forms.TextBox
        Me.Image1 = New System.Windows.Forms.PictureBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.ReadLabel = New System.Windows.Forms.Label
        CType(Me.Image1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CursorRightBtn
        '
        Me.CursorRightBtn.BackColor = System.Drawing.SystemColors.Control
        Me.CursorRightBtn.Cursor = System.Windows.Forms.Cursors.Default
        Me.CursorRightBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CursorRightBtn.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CursorRightBtn.Location = New System.Drawing.Point(116, 156)
        Me.CursorRightBtn.Name = "CursorRightBtn"
        Me.CursorRightBtn.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CursorRightBtn.Size = New System.Drawing.Size(49, 34)
        Me.CursorRightBtn.TabIndex = 12
        Me.CursorRightBtn.Text = "Cursor Right"
        Me.ToolTip1.SetToolTip(Me.CursorRightBtn, "Move cursor to the right")
        Me.CursorRightBtn.UseVisualStyleBackColor = False
        '
        'CursorLeftBtn
        '
        Me.CursorLeftBtn.BackColor = System.Drawing.SystemColors.Control
        Me.CursorLeftBtn.Cursor = System.Windows.Forms.Cursors.Default
        Me.CursorLeftBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CursorLeftBtn.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CursorLeftBtn.Location = New System.Drawing.Point(62, 156)
        Me.CursorLeftBtn.Name = "CursorLeftBtn"
        Me.CursorLeftBtn.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CursorLeftBtn.Size = New System.Drawing.Size(49, 34)
        Me.CursorLeftBtn.TabIndex = 11
        Me.CursorLeftBtn.Text = "Cursor Left"
        Me.ToolTip1.SetToolTip(Me.CursorLeftBtn, "Move cursor to the left")
        Me.CursorLeftBtn.UseVisualStyleBackColor = False
        '
        'ToggleCursorButton
        '
        Me.ToggleCursorButton.BackColor = System.Drawing.SystemColors.Control
        Me.ToggleCursorButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.ToggleCursorButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToggleCursorButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ToggleCursorButton.Location = New System.Drawing.Point(8, 156)
        Me.ToggleCursorButton.Name = "ToggleCursorButton"
        Me.ToggleCursorButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ToggleCursorButton.Size = New System.Drawing.Size(49, 34)
        Me.ToggleCursorButton.TabIndex = 10
        Me.ToggleCursorButton.Text = "Cursor"
        Me.ToolTip1.SetToolTip(Me.ToggleCursorButton, "Toggle cursor on or off")
        Me.ToggleCursorButton.UseVisualStyleBackColor = False
        '
        'SetDRAMAddrButton
        '
        Me.SetDRAMAddrButton.BackColor = System.Drawing.SystemColors.Control
        Me.SetDRAMAddrButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.SetDRAMAddrButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SetDRAMAddrButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.SetDRAMAddrButton.Location = New System.Drawing.Point(224, 104)
        Me.SetDRAMAddrButton.Name = "SetDRAMAddrButton"
        Me.SetDRAMAddrButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SetDRAMAddrButton.Size = New System.Drawing.Size(57, 34)
        Me.SetDRAMAddrButton.TabIndex = 9
        Me.SetDRAMAddrButton.Text = "DDRAM Addr"
        Me.ToolTip1.SetToolTip(Me.SetDRAMAddrButton, "Set DDRAM (cursor) address")
        Me.SetDRAMAddrButton.UseVisualStyleBackColor = False
        '
        'LCDHomeButton
        '
        Me.LCDHomeButton.BackColor = System.Drawing.SystemColors.Control
        Me.LCDHomeButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.LCDHomeButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LCDHomeButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LCDHomeButton.Location = New System.Drawing.Point(116, 104)
        Me.LCDHomeButton.Name = "LCDHomeButton"
        Me.LCDHomeButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LCDHomeButton.Size = New System.Drawing.Size(49, 34)
        Me.LCDHomeButton.TabIndex = 5
        Me.LCDHomeButton.Text = "Home"
        Me.ToolTip1.SetToolTip(Me.LCDHomeButton, "Move cursor to home position")
        Me.LCDHomeButton.UseVisualStyleBackColor = False
        '
        'LcdClearButton
        '
        Me.LcdClearButton.BackColor = System.Drawing.SystemColors.Control
        Me.LcdClearButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.LcdClearButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LcdClearButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LcdClearButton.Location = New System.Drawing.Point(62, 104)
        Me.LcdClearButton.Name = "LcdClearButton"
        Me.LcdClearButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LcdClearButton.Size = New System.Drawing.Size(49, 34)
        Me.LcdClearButton.TabIndex = 2
        Me.LcdClearButton.Text = "CLR"
        Me.ToolTip1.SetToolTip(Me.LcdClearButton, "Clear LCD screen")
        Me.LcdClearButton.UseVisualStyleBackColor = False
        '
        'LCDInitButton
        '
        Me.LCDInitButton.BackColor = System.Drawing.SystemColors.Control
        Me.LCDInitButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.LCDInitButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LCDInitButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LCDInitButton.Location = New System.Drawing.Point(8, 104)
        Me.LCDInitButton.Name = "LCDInitButton"
        Me.LCDInitButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LCDInitButton.Size = New System.Drawing.Size(49, 34)
        Me.LCDInitButton.TabIndex = 1
        Me.LCDInitButton.Text = "Init"
        Me.ToolTip1.SetToolTip(Me.LCDInitButton, "Init LCD display")
        Me.LCDInitButton.UseVisualStyleBackColor = False
        '
        'TextVal2
        '
        Me.TextVal2.AcceptsReturn = True
        Me.TextVal2.BackColor = System.Drawing.SystemColors.Window
        Me.TextVal2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextVal2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TextVal2.Location = New System.Drawing.Point(248, 32)
        Me.TextVal2.MaxLength = 0
        Me.TextVal2.Name = "TextVal2"
        Me.TextVal2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextVal2.Size = New System.Drawing.Size(33, 25)
        Me.TextVal2.TabIndex = 7
        Me.TextVal2.Text = "0"
        '
        'LCDWriteButton
        '
        Me.LCDWriteButton.BackColor = System.Drawing.SystemColors.Control
        Me.LCDWriteButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.LCDWriteButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LCDWriteButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LCDWriteButton.Location = New System.Drawing.Point(170, 104)
        Me.LCDWriteButton.Name = "LCDWriteButton"
        Me.LCDWriteButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LCDWriteButton.Size = New System.Drawing.Size(49, 34)
        Me.LCDWriteButton.TabIndex = 6
        Me.LCDWriteButton.Text = "Write"
        Me.LCDWriteButton.UseVisualStyleBackColor = False
        '
        'TextVal1
        '
        Me.TextVal1.AcceptsReturn = True
        Me.TextVal1.BackColor = System.Drawing.SystemColors.Window
        Me.TextVal1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextVal1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TextVal1.Location = New System.Drawing.Point(8, 32)
        Me.TextVal1.MaxLength = 0
        Me.TextVal1.Name = "TextVal1"
        Me.TextVal1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextVal1.Size = New System.Drawing.Size(233, 25)
        Me.TextVal1.TabIndex = 0
        '
        'Image1
        '
        Me.Image1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Image1.Image = CType(resources.GetObject("Image1.Image"), System.Drawing.Image)
        Me.Image1.Location = New System.Drawing.Point(182, 144)
        Me.Image1.Name = "Image1"
        Me.Image1.Size = New System.Drawing.Size(99, 45)
        Me.Image1.TabIndex = 13
        Me.Image1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(200, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(88, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "DDRAM Address"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(8, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(73, 17)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "String to write"
        '
        'ReadLabel
        '
        Me.ReadLabel.BackColor = System.Drawing.SystemColors.Control
        Me.ReadLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.ReadLabel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ReadLabel.Location = New System.Drawing.Point(8, 80)
        Me.ReadLabel.Name = "ReadLabel"
        Me.ReadLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ReadLabel.Size = New System.Drawing.Size(177, 17)
        Me.ReadLabel.TabIndex = 3
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(294, 200)
        Me.Controls.Add(Me.CursorRightBtn)
        Me.Controls.Add(Me.CursorLeftBtn)
        Me.Controls.Add(Me.ToggleCursorButton)
        Me.Controls.Add(Me.SetDRAMAddrButton)
        Me.Controls.Add(Me.TextVal2)
        Me.Controls.Add(Me.LCDWriteButton)
        Me.Controls.Add(Me.LCDHomeButton)
        Me.Controls.Add(Me.LcdClearButton)
        Me.Controls.Add(Me.LCDInitButton)
        Me.Controls.Add(Me.TextVal1)
        Me.Controls.Add(Me.Image1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ReadLabel)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Location = New System.Drawing.Point(4, 30)
        Me.Name = "Form1"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "IO-Warrior LCD sample"
        CType(Me.Image1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
#End Region 
End Class