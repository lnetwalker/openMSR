//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by LCD_Sample.rc
//
#define IDD_LCD_SAMPLE_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDC_LCDCLEAR                    1000
#define IDC_WRITESTRING                 1001
#define IDC_RADIO1                      1002
#define IDC_LCDONOFF                    1003
#define IDC_READLIST                    1004
#define IDC_LCDTEST                     1005
#define IDC_LCDHOME                     1006
#define IDC_LCDCURSOR                   1007
#define IDC_WRITEDATA                   1011
#define IDC_RADIO2                      1012
#define IDC_RADIO3                      1013
#define IDC_CLEARLIST                   1014
#define IDC_READDATA                    1015
#define IDC_INITIATE                    1016
#define IDC_CLEARREPORT                 1017
#define IDC_MOVEBW                      1018
#define IDC_MOVEFW                      1019
#define IDC_REPORTLIST                  1020
#define IDC_WRITEDATA2                  1021
#define IDC_COUNTER                     1022
#define IDC_2LINE                       1023
#define IDC_CHARFW                      1025
#define IDC_CHARFW2                     1026
#define IDC_CHARBW                      1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
