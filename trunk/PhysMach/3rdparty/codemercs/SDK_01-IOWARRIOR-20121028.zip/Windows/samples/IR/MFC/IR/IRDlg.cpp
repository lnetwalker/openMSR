// IRDlg.cpp : implementation file
//

#include "stdafx.h"
#include "IR.h"
#include "IRDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CIRDlg dialog

CIRDlg::CIRDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CIRDlg::IDD, pParent)
	, m_status(_T(""))
	, m_save(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CIRDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_RECIVE, m_recive);
	DDX_Text(pDX, IDC_STATUS, m_status);
}

BEGIN_MESSAGE_MAP(CIRDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_CLEAR, &CIRDlg::OnBnClickedClear)
	ON_WM_CLOSE()
END_MESSAGE_MAP()

// CIRDlg message handlers

BOOL CIRDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	//create the Colums for ListCtrl and the style
	m_recive.InsertColumn(0, "DATA", NULL, 100);
	m_recive.SetExtendedStyle(LVS_EX_GRIDLINES);

	//Open the IOWarrior
	iowHandle = IowKitOpenDevice();

	//If IOW24 found, write orders
	if(iowHandle != NULL && IowKitGetProductId(iowHandle) == IOWKIT_PRODUCT_ID_IOW24)
	{
		IOWKIT_SPECIAL_REPORT report;

		memset(&report, 0, IOWKIT_SPECIAL_REPORT_SIZE);
		report.ReportID = 0x0C; //Setup the IOW24 with IR-function
		report.Bytes[0] = 0x01; //Enable the IR-function

		//Write to the IOWarrior
		IowKitWrite(iowHandle, IOW_PIPE_SPECIAL_MODE, (char *) &report, IOWKIT_SPECIAL_REPORT_SIZE);

		m_status = "IOWarrior 24 found";
	}
	else
	{
		//If no IOW or wrong found, close IOWarrior
		IowKitCloseDevice(iowHandle);
		MessageBox("Please connect an IOWarrior 24 and run the program again.", "No IOWarrior 24 found", NULL);
		OnOK();
	}

	//Start timer
	SetTimer(IDC_LOOPTIMER, 100, NULL);
	UpdateData(FALSE);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CIRDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CIRDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CIRDlg::OnTimer(UINT_PTR nIDEvent)
{
	IOWKIT_SPECIAL_REPORT report;
	CString rec;

	memset(&report, 0, IOWKIT_SPECIAL_REPORT_SIZE);
	
	// Read the data bytes from IOWarrior and display them
	if (IowKitReadNonBlocking(iowHandle, IOW_PIPE_SPECIAL_MODE, (char *) &report, IOWKIT_SPECIAL_REPORT_SIZE) &&
        report.ReportID == 0x0C)
    {
    	// transform the byte for insert into ListCtrl
	    rec.Format("%d", report.Bytes[0]);
	
	    // Prevent same inserts one behind the other
	    if(m_save != report.Bytes[0])
		{
			m_recive.InsertItem(m_recive.GetItemCount()+1, rec);

			// Example for using recived bytes
			// Close the programm by readin "0"
			if(report.Bytes[0] == 0x00)
            {
                CloseDevice();
                OnOK();
            }
            else
			// Start the calculator from Windows
			if(report.Bytes[0] == 0x01)
                WinExec("calc.exe", SW_SHOW);
		}

	    // Do autoscroll after last insert
	    m_recive.EnsureVisible(m_recive.GetItemCount()-1, TRUE);

	    // Save the last recived byte
	    m_save = report.Bytes[0];

	    UpdateData(FALSE);
    }

	CDialog::OnTimer(nIDEvent);
}

void CIRDlg::OnBnClickedClear()
{
	//Clear the ListCtrl
	m_recive.DeleteAllItems();
	UpdateData(FALSE);
}

void CIRDlg::CloseDevice(void)
{
	IOWKIT_SPECIAL_REPORT report;

    if(iowHandle != NULL)
    {
	    memset(&report, 0, IOWKIT_SPECIAL_REPORT_SIZE);
	    report.ReportID = 0x0C; 
	    report.Bytes[0] = 0x00; 

	    IowKitWrite(iowHandle, IOW_PIPE_SPECIAL_MODE, (char *) &report, IOWKIT_SPECIAL_REPORT_SIZE);
    }

    IowKitCloseDevice(iowHandle);
}

void CIRDlg::OnClose()
{
    CloseDevice();
	CDialog::OnClose();
}
