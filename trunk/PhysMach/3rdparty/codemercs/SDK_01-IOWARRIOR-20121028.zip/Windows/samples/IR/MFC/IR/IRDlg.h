// IRDlg.h : header file
//

#pragma once
#include "afxcmn.h"
#include "iowkit.h"


// CIRDlg dialog
class CIRDlg : public CDialog
{
// Construction
public:
	CIRDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_IR_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CListCtrl m_recive;
	CString m_status;
	IOWKIT_HANDLE iowHandle;
	unsigned long m_save;
    void CloseDevice(void);
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedClear();
	afx_msg void OnClose();
};
