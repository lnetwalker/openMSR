Enclosed is a Delphi component for using HID class USB devices.

This component has been written by Robert Marquardt of Team Jedi (http://delphi-jedi.org).
It is not specifically written for using IO-Warrior but it allows to use IO-Warrior as it 
does allow to use virtually any HID Class device.

In the folder "DEMOS" you will find examples how to use the component with IO-Warrior.

Thanks a lot to Robert for allowing us to include his component in our SDK.

If you want to check for new releases of this component please visit:
http://www.soft-gems.net

The download service is available thanks to Mike Lischke.
