IO-Warrior SDK V1.5.1

New in this release:

Several bugs of the 1.4 API have been fixed and some functions added to the API.

The examples have been reorganized and several new ones have been added.
Notably MS VC++ 2005 examples have been created. The VB6 examples now convert to VB.net
without problems. The VB.net examples should work with VB.net Express.

Known problems:

IowKitCloseDevice must be called before exiting a program otherwise the program will hang
and has to be shot down through Task Manager.


The central directory is the "library_1_5" directory.
It contains the iowkit.dll and all files needed for access with C/C++, Delphi,
Visual Basic 6 or Visual Basic .net.
The source for the DLL is provided as "Visual Studio 2005" project.

The examples have been regrouped. Each functionality has its own directory.
"IIC", "IR", "LCD", "LED Matrix", "Simple IO", "SPI", and so on.
"General HID Tools" is a nice test tool for any HID device.
Inside those directories each supported programming language has its own subdirectory.
"C", "MFC", "Delphi", "VB6" and "VB.net".


How to set up the kit:
Simply make a new directory and copy the kit contents to it.
Then copy library\iowkit.dll to system DLLs directory
(winnt\system32 directory in Windows 2000, windows\system32 in WinXP.

Borland Delphi:
Install the HID component from Delphi\HIDKomponente in the usual way,
ie doubleclick HidController.dpk and click Install.
Add the path to this directory to the global library path of the Delphi IDE.
If you have the JediVCL (http://jvcl.sf.net) installed then you do not need to
install the component because it is also part of the JVCL.
