codemercs.jar contains the Java class to access the IOW Kit API directly.
It is implemented via JNI in iowkit.dll for Windows and libiowkit.so for Linux 2.6.
The source IowKit.java contains Javadoc.

Code Mercenaries wants to thank Thomas Wagner <thomas@wagner-ibw.de> and Eberhard Fahle <e.fahle@wayoda.org>
for their generous help to make the Java support for IO-Warrior on Windows and Linux possible.

Thomas Wagner has written several Java classes and sample programs for the IO-Warrior under the GPL.
Have a look at http://www.wagner-ibw.de where you can download them.