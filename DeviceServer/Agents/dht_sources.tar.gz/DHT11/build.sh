gcc -o dht11 dht11.c -L/usr/local/lib -lwiringPi
